-- DZ Auto - idea e sviluppo by Daniel Zavan
-- Plugin per Lightroom Classic: un pannello che sistema il servizio da solo (stile, bianco ed esposizione automatici,
-- raddrizza, bianco e nero, firma), Torna come prima, consegna in ordine di scatto, avvisi, aggiornamento da solo.

return {
  LrSdkVersion = 12.0,
  LrSdkMinimumVersion = 10.0,
  LrToolkitIdentifier = 'it.dzapp.dzauto',
  LrPluginName = 'DZ Auto',
  LrPluginInfoUrl = 'https://milkbarandcoffe-web.github.io/lightroom/guida/',
  LrPluginInfoProvider = 'PluginInfo.lua',
  LrExportMenuItems = {
    { title = 'DZ Auto: Pannello', file = 'MenuPannello.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Avvia con le ultime scelte', file = 'MenuAvvia.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Torna come prima', file = 'MenuTorna.lua' },
    { title = 'DZ Auto: Allinea orologi', file = 'MenuAllinea.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Esporta consegna', file = 'MenuEsporta.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Aggiorna', file = 'MenuAggiorna.lua' },
    { title = 'DZ Auto: Aiuto e messaggi', file = 'MenuAiuto.lua' },
    { title = 'DZ Auto: Manda segnalazione', file = 'MenuSegnala.lua' }
  },
  LrLibraryMenuItems = {
    { title = 'DZ Auto: Pannello', file = 'MenuPannello.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Avvia con le ultime scelte', file = 'MenuAvvia.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Torna come prima', file = 'MenuTorna.lua' },
    { title = 'DZ Auto: Aiuto e messaggi', file = 'MenuAiuto.lua' }
  },
  VERSION = { major = 2, minor = 0, revision = 1, build = 5 }
}
