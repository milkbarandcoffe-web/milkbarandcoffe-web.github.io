-- DZ Auto - idea e sviluppo by Daniel Zavan
-- Plugin per Lightroom Classic: preset per fotocamera, consegna in ordine di scatto, firma, avvisi.

return {
  LrSdkVersion = 12.0,
  LrSdkMinimumVersion = 10.0,
  LrToolkitIdentifier = 'it.dzapp.dzauto',
  LrPluginName = 'DZ Auto',
  LrPluginInfoUrl = 'https://milkbarandcoffe-web.github.io/lightroom/guida/',
  LrPluginInfoProvider = 'PluginInfo.lua',
  LrExportMenuItems = {
    { title = 'DZ Auto: Applica preset', file = 'MenuApplicaPreset.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Allinea orologi', file = 'MenuAllinea.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Firma e copyright', file = 'MenuFirma.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Esporta consegna', file = 'MenuEsporta.lua', enabledWhen = 'photosAvailable' },
    { title = 'DZ Auto: Domande e suggerimenti', file = 'MenuDomande.lua' }
  },
  VERSION = { major = 1, minor = 1, revision = 1, build = 3 }
}
