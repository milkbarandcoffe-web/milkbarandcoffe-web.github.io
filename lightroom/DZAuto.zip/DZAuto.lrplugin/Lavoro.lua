-- DZ Auto 2.0 - idea e sviluppo by Daniel Zavan
-- Il lavoro del pannello, foto per foto: istantanea "prima", il tuo stile per fotocamera, bianco ed esposizione
-- automatici, raddrizza, bianco e nero sulle foto con l'etichetta scelta, firma. Poi raccolta, avviso e conteggi.
-- Torna come prima: rimette l'istantanea "prima" sulle foto dell'ultimo lavoro.

local LrApplication = import 'LrApplication'
local LrDialogs = import 'LrDialogs'
local LrProgressScope = import 'LrProgressScope'

local Core = require 'Core'
local Json = require 'Json'

local Lavoro = {}
Lavoro.GRUPPO = 10
Lavoro.PROVA = 20
-- Trasforma > Upright > Livello. Valore preso dal forum Adobe: la "Prova su 20 foto" controlla che Lightroom lo accetti.
Lavoro.UPRIGHT_LIVELLO = 3

local function bool(v, def)
  if v == nil then return def end
  return v == true
end

-- Preset per nome: prima il nome esatto, poi (se non soloEsatto) il nome che contiene la parola. Ritorna l'uuid o nil.
-- "Automatico" solo con il nome esatto: un preset di Adobe con un nome simile potrebbe contenere altre impostazioni.
Lavoro.NOMI_AUTO = { 'automatico', 'dz auto automatico' }
Lavoro.NOMI_BN = { 'area bn', 'bianco e nero', 'bianco nero', ' bn', 'b&w' }
function Lavoro.cercaPreset(parole, elenco, soloEsatto)
  elenco = elenco or Core.preset()
  for _, w in ipairs(parole) do
    for _, pr in ipairs(elenco) do
      if (pr.titolo:lower():gsub('^.- / ', '')) == w then return pr.uuid end
    end
  end
  if soloEsatto then return nil end
  for _, w in ipairs(parole) do
    for _, pr in ipairs(elenco) do
      if pr.titolo:lower():find(w, 1, true) then return pr.uuid end
    end
  end
  return nil
end

-- Scelte del pannello (salvate nelle preferenze del plugin). Preset "Automatico" e bianco e nero: se mancano, li cerco per nome.
function Lavoro.opzioni()
  local p = Core.prefs()
  local stile = {}
  for k, v in pairs(p.presetPerCamera or {}) do stile[k] = v end
  return {
    colore = bool(p.pColore, true),
    stile = stile,
    forza = math.max(0, math.min(200, math.floor(tonumber(p.pForza) or 100))),
    bianco = bool(p.pBianco, true),
    tono = bool(p.pTono, true),
    autoPreset = p.pAutoPreset or Lavoro.cercaPreset(Lavoro.NOMI_AUTO, nil, true),
    raddrizza = bool(p.pRaddrizza, true),
    bn = bool(p.pBN, false),
    bnEtichetta = p.pBNEtichetta or 'blue',
    bnPreset = p.pBNPreset or Lavoro.cercaPreset(Lavoro.NOMI_BN),
    firma = bool(p.pFirma, true),
    soloScelte = bool(p.pSoloScelte, false),
    avviso = bool(p.pAvviso, true),
    mostra = bool(p.pMostra, true)
  }
end

function Lavoro.salva(o)
  local p = Core.prefs()
  p.pColore, p.pForza, p.pBianco, p.pTono, p.pAutoPreset = o.colore, o.forza, o.bianco, o.tono, o.autoPreset
  p.pRaddrizza, p.pBN, p.pBNEtichetta, p.pBNPreset = o.raddrizza, o.bn, o.bnEtichetta, o.bnPreset
  p.pFirma, p.pSoloScelte, p.pAvviso, p.pMostra = o.firma, o.soloScelte, o.avviso, o.mostra
  local s = {}
  for k, v in pairs(o.stile or {}) do s[k] = v end
  p.presetPerCamera = s
end

-- Le foto su cui lavorare: le selezionate (se piu di una) oppure tutte quelle visibili, in ordine di scatto.
function Lavoro.foto(catalog, o)
  local dati = Core.datiScatto(catalog, catalog:getMultipleSelectedOrAllPhotos() or {})
  if o and o.soloScelte then
    local f = {}
    for _, d in ipairs(dati) do
      if d.scelta then f[#f + 1] = d end
    end
    dati = f
  end
  return Core.ordina(dati)
end

-- Prova: n foto sparse su tutto il servizio, almeno una per fotocamera e per etichetta.
function Lavoro.campione(dati, n)
  if #dati <= n then return dati end
  local scelti, visti = {}, {}
  local function metti(d)
    if d and not visti[d] and #scelti < n then
      visti[d] = true
      scelti[#scelti + 1] = d
    end
  end
  local primi = {}
  for _, d in ipairs(dati) do
    local k = d.modello .. '|' .. d.etichetta
    if not primi[k] then
      primi[k] = true
      metti(d)
    end
  end
  local passo = #dati / n
  for i = 0, n - 1 do metti(dati[math.floor(i * passo) + 1]) end
  for _, d in ipairs(dati) do metti(d) end
  return Core.ordina(scelti)
end

-- Ultimo lavoro salvato (per Torna come prima e per rifare una prova senza lavoro doppio).
function Lavoro.ultimo()
  local u = Json.decode(Core.prefs().ultimoLavoro or '')
  if type(u) ~= 'table' or type(u.uuid) ~= 'table' or #u.uuid == 0 then return nil end
  return u
end

-- Se l'ultimo lavoro era una prova: le sue foto ripartono dall'istantanea "prima" (il preset non va messo due volte).
function Lavoro.provaDaRifare(dati)
  local u = Lavoro.ultimo()
  if not u or not u.prova then return nil end
  local set, n = {}, 0
  for _, id in ipairs(u.uuid) do set[id] = true end
  for _, d in ipairs(dati) do
    if d.uuid and set[d.uuid] then n = n + 1 end
  end
  if n == 0 then return nil end
  return { nome = u.nome, set = set, n = n }
end

-- Rimette l'istantanea con questo nome (errore se la foto non ce l'ha).
function Lavoro.applicaIstantanea(f, nome)
  local id
  for _, s in ipairs(f:getDevelopSnapshots() or {}) do
    if s.name == nome then id = s.snapshotID end
  end
  if not id then error('istantanea "' .. tostring(nome) .. '" non trovata', 0) end
  f:applyDevelopSnapshot(id)
end

local function nomiPreset()
  local m = {}
  for _, pr in ipairs(Core.preset()) do m[pr.uuid] = (pr.titolo:gsub('^.- / ', '')) end
  return m
end

-- Cosa fara il lavoro in parole semplici. Ritorna righe, problemi (bloccano) e avvisi (si puo continuare).
function Lavoro.piano(o, dati)
  local righe, problemi, avvisi = {}, {}, {}
  if #dati == 0 then
    problemi[#problemi + 1] = o.soloScelte and 'Nessuna foto con la bandierina "scelta": togli la spunta nella scheda Scelta o metti le bandierine.'
      or 'Nessuna foto: apri una cartella o una raccolta.'
    return righe, problemi, avvisi
  end
  local nomi = nomiPreset()
  local modelli, conta = Core.modelli(dati)
  local nBN = 0
  for _, d in ipairs(dati) do
    if d.etichetta == o.bnEtichetta then nBN = nBN + 1 end
  end
  local qualcosa = false
  if o.colore then
    local parti = {}
    for _, m in ipairs(modelli) do
      local n = nomi[o.stile[m]]
      parti[#parti + 1] = string.format('%s (%d): %s', m, conta[m], n and ('"' .. n .. '"') or 'nessun preset')
    end
    righe[#righe + 1] = 'Il tuo stile: ' .. table.concat(parti, '; ')
    if o.bianco then righe[#righe + 1] = 'Bianco automatico foto per foto' end
    if o.tono then
      if nomi[o.autoPreset] then
        righe[#righe + 1] = 'Esposizione automatica foto per foto (preset "' .. nomi[o.autoPreset] .. '")'
      else
        avvisi[#avvisi + 1] = 'Esposizione automatica: manca il preset "Automatico" (scheda Colore). Per ora la salto.'
      end
    end
    qualcosa = true
  end
  if o.raddrizza then
    righe[#righe + 1] = 'Raddrizza (Upright Livello di Lightroom)'
    qualcosa = true
  end
  if o.bn then
    if not nomi[o.bnPreset] then
      avvisi[#avvisi + 1] = 'Bianco e nero: scegli il preset (scheda Bianco e nero). Per ora lo salto.'
    else
      righe[#righe + 1] = string.format('Bianco e nero "%s" sulle foto con etichetta %s: %d adesso',
        nomi[o.bnPreset], Core.nomeEtichetta(o.bnEtichetta), nBN)
      qualcosa = true
    end
  end
  if o.firma then
    if Core.firmaPronta() then
      righe[#righe + 1] = 'Firma e copyright'
      qualcosa = true
    else
      avvisi[#avvisi + 1] = 'Firma: scrivi autore o copyright (scheda Altro). Per ora la salto.'
    end
  end
  if not qualcosa then
    problemi[#problemi + 1] = 'Niente da fare: attiva almeno una voce nel pannello.'
  end
  local rif = Lavoro.provaDaRifare(dati)
  if rif then
    righe[#righe + 1] = string.format('Le %d foto della prova di prima ripartono da com\'erano (niente lavoro doppio)', rif.n)
  end
  return righe, problemi, avvisi
end

function Lavoro.sorgente(catalog)
  local ok, s = Core.pcall(function() return catalog:getActiveSources() end)
  if ok and type(s) == 'table' and s[1] and type(s[1]) ~= 'string' then
    local ok2, n = Core.pcall(function() return s[1]:getName() end)
    if ok2 and n and n ~= '' then return n end
  end
  return 'foto'
end

local CONTROLLO = { 'PerspectiveUpright', 'CropConstrainToWarp', 'WhiteBalance', 'Temperature', 'Exposure2012', 'ConvertToGrayscale' }

local function impostazioni(f)
  local ok, s = Core.pcall(function() return f:getDevelopSettings() end)
  if ok and type(s) == 'table' then return s end
  return {}
end

-- Il lavoro. prova = true: niente avviso sul telefono, raccolta "prova" e controllo delle impostazioni nel riepilogo.
function Lavoro.esegui(context, o, dati, prova)
  local catalog = LrApplication.activeCatalog()
  local inizio = os.time()
  local cache = {}
  local function preset(u)
    if not u or u == '-' or u == '' then return nil end
    if cache[u] == nil then cache[u] = Core.trovaPreset(u) or false end
    return cache[u] or nil
  end
  local autoP = (o.colore and o.tono) and preset(o.autoPreset) or nil
  local bnP = o.bn and preset(o.bnPreset) or nil
  local firma = o.firma and Core.firmaPronta()
  local nomeIst = 'DZ Auto - prima ' .. os.date('%d/%m/%Y %H:%M:%S')
  local prec = Lavoro.ultimo()
  if prec and prec.nome == nomeIst then nomeIst = nomeIst .. ' (2)' end
  local conti = { istantanea = 0, riparti = 0, stile = 0, bianco = 0, tono = 0, raddrizza = 0, bn = 0, firma = 0 }
  local rifai = Lavoro.provaDaRifare(dati)
  local colorate = 0
  local errori, fatte = {}, {}
  local function passo(nome, fn)
    local ok, e = Core.pcall(fn)
    if ok then
      conti[nome] = conti[nome] + 1
    else
      local x = errori[nome] or { n = 0 }
      x.n = x.n + 1
      x.primo = x.primo or tostring(e)
      errori[nome] = x
    end
    return ok
  end

  local primo = dati[1] and dati[1].foto
  local prima = {}

  local function lavora(d)
    local f = d.foto
    if rifai and d.uuid and rifai.set[d.uuid] then
      local ok, e = Core.pcall(Lavoro.applicaIstantanea, f, rifai.nome)
      if ok then conti.riparti = conti.riparti + 1 else Core.log('Prova non annullata su ' .. tostring(d.nome) .. ': ' .. tostring(e)) end
    end
    if f == primo then prima = impostazioni(f) end
    -- Senza istantanea "prima" la foto non si tocca.
    local ok, e = Core.pcall(function() return f:createDevelopSnapshot(nomeIst, true) end)
    if not ok or e == false then error('istantanea "prima" non salvata: ' .. tostring(e), 0) end
    conti.istantanea = conti.istantanea + 1
    fatte[#fatte + 1] = d
    local colorata = false
    if bnP and d.etichetta == o.bnEtichetta then
      passo('bn', function() f:applyDevelopPreset(bnP, _PLUGIN) end)
    elseif o.colore then
      local u = o.stile[d.modello]
      local st = preset(u)
      if u and not st then
        passo('stile', function() error('preset non trovato in Lightroom: sceglilo di nuovo nella scheda Colore', 0) end)
      elseif st and passo('stile', function()
        if o.forza ~= 100 then f:applyDevelopPreset(st, _PLUGIN, o.forza) else f:applyDevelopPreset(st, _PLUGIN) end
      end) then colorata = true end
      if o.bianco and passo('bianco', function() f:quickDevelopSetWhiteBalance('Auto') end) then colorata = true end
    end
    if autoP and passo('tono', function() f:applyDevelopPreset(autoP, _PLUGIN) end) then colorata = true end
    if colorata then colorate = colorate + 1 end
    if o.raddrizza then
      passo('raddrizza', function()
        f:applyDevelopSettings({ EnableTransform = true, PerspectiveUpright = Lavoro.UPRIGHT_LIVELLO, CropConstrainToWarp = 1 }, 'DZ Auto: raddrizza')
      end)
    end
    if firma then passo('firma', function() Core.scriviFirma(f) end) end
  end

  local avanz = LrProgressScope { title = prova and 'DZ Auto: prova su ' .. #dati .. ' foto' or 'DZ Auto: lavoro in corso', functionContext = context }
  Core.log(string.format('%s: %d foto, istantanea "%s"', prova and 'Prova' or 'Lavoro', #dati, nomeIst))
  local _, erroriFoto = Core.aGruppi(catalog, 'DZ Auto', dati, Lavoro.GRUPPO, lavora, avanz)
  local interrotto = avanz:isCanceled()
  avanz:done()

  -- Controllo sulla prima foto: Lightroom ha preso davvero le impostazioni?
  local verifica = {}
  if primo and #fatte > 0 and fatte[1].foto == primo then
    local dopo = impostazioni(primo)
    local diff = {}
    for _, k in ipairs(CONTROLLO) do diff[#diff + 1] = k .. ' ' .. tostring(prima[k]) .. ' -> ' .. tostring(dopo[k]) end
    Core.log('Controllo prima foto: ' .. table.concat(diff, '; '))
    if o.raddrizza and conti.raddrizza > 0 then
      verifica[#verifica + 1] = tonumber(dopo.PerspectiveUpright) == Lavoro.UPRIGHT_LIVELLO and 'raddrizza preso da Lightroom'
        or ('raddrizza NON preso da Lightroom (valore ' .. tostring(dopo.PerspectiveUpright) .. ')')
    end
    if conti.bianco > 0 then
      verifica[#verifica + 1] = tostring(dopo.WhiteBalance) == 'Auto' and 'bianco automatico preso'
        or ('bianco: ' .. tostring(dopo.WhiteBalance))
    end
    if conti.tono > 0 then
      verifica[#verifica + 1] = 'esposizione ' .. tostring(prima.Exposure2012) .. ' -> ' .. tostring(dopo.Exposure2012)
    end
  end

  -- Raccolta con le foto lavorate e dati per "Torna come prima".
  local nomeR = os.date('%Y-%m-%d %H.%M') .. (prova and ' prova' or '') .. ' - ' .. Lavoro.sorgente(catalog)
  local raccolta
  if #fatte > 0 then
    local ok, e = Core.pcall(function()
      catalog:withWriteAccessDo('DZ Auto: raccolta', function()
        local set = catalog:createCollectionSet('DZ Auto', nil, true)
        raccolta = catalog:createCollection(nomeR, set, true)
        local l = {}
        for _, d in ipairs(fatte) do l[#l + 1] = d.foto end
        if raccolta then raccolta:addPhotos(l) end
      end, { timeout = 60 })
    end)
    if not ok then
      Core.log('Raccolta non creata: ' .. tostring(e))
      raccolta = nil
    end
    local u = {}
    for _, d in ipairs(fatte) do
      if d.uuid then u[#u + 1] = d.uuid end
    end
    Core.prefs().ultimoLavoro = Json.encode({ nome = nomeIst, quando = os.date('%d/%m/%Y %H:%M'), raccolta = nomeR, prova = prova and true or false, uuid = u })
  end

  -- Tempo risparmiato (stima) e conteggi anonimi.
  local risp = 0
  if colorate > 0 then risp = risp + Core.segna('colore', colorate) end
  if conti.raddrizza > 0 then risp = risp + Core.segna('raddrizza', conti.raddrizza) end
  if conti.bn > 0 then risp = risp + Core.segna('bn', conti.bn) end
  if conti.firma > 0 then risp = risp + Core.segna('firma', 1) end

  local r = {
    n = #dati, fatte = #fatte, conti = conti, errori = errori, erroriFoto = erroriFoto, verifica = verifica,
    durata = os.time() - inizio, raccolta = raccolta and nomeR or nil, risparmio = risp, interrotto = interrotto, prova = prova
  }
  for k, x in pairs(errori) do Core.log('Errori ' .. k .. ': ' .. x.n .. ', primo: ' .. tostring(x.primo)) end
  for _, e in ipairs(erroriFoto or {}) do Core.log('Foto non toccata: ' .. tostring(e)) end

  if not prova and o.avviso and #fatte > 0 then
    local ok, m = Core.avviso('DZ Auto: lavoro finito', string.format('%d foto sistemate in %s. Le trovi nella raccolta DZ Auto > %s. Tempo risparmiato (stima): circa %s.',
      #fatte, Lavoro.durata(r.durata), nomeR, Core.testoDurata(risp)))
    r.avviso = ok and true or m
  end
  Core.inviaConteggi()
  if o.mostra and raccolta then
    Core.pcall(function() catalog:setActiveSources({ raccolta }) end)
  end
  return r
end

-- Finestra di fine lavoro. Prova o errori: tasto "Manda a DZ Auto" (riepilogo + diagnostica nella pagina Aiuto).
function Lavoro.mostraFine(r)
  local t = Lavoro.testo(r)
  Core.prefs().ultimoRiepilogo = os.date('%d/%m/%Y %H:%M') .. '\n' .. t
  local problemi = next(r.errori) ~= nil or #(r.erroriFoto or {}) > 0
  local titolo = r.prova and 'DZ Auto: prova finita' or 'DZ Auto: fatto'
  local Aiuto = require 'Aiuto'
  if (r.prova or problemi) and Aiuto.indirizzo() then
    local s = LrDialogs.confirm(titolo, t .. '\n\nMandi questo riepilogo a DZ Auto? Lo leggiamo e ti rispondiamo nella pagina Aiuto.', 'Manda a DZ Auto', 'Chiudi')
    if s == 'ok' then
      local ok, motivo = Aiuto.segnala({ tipo = r.prova and 'Prova fatta' or 'Segnalazione', testo = '', riepilogo = true, diagnostica = true, schermata = false })
      LrDialogs.message('DZ Auto', ok and 'Mandato: grazie! La risposta arriva nella pagina Aiuto (File > Extra plug-in > DZ Auto: Aiuto e messaggi).'
        or ('Non mandato: ' .. tostring(motivo)), ok and 'info' or 'warning')
    end
    return
  end
  LrDialogs.message(titolo, t, problemi and 'warning' or 'info')
end

function Lavoro.durata(s)
  s = tonumber(s) or 0
  if s < 60 then return s .. ' s' end
  return Core.testoDurata(s)
end

local NOMI = { stile = 'Il tuo stile', bianco = 'Bianco automatico', tono = 'Esposizione automatica', raddrizza = 'Raddrizza', bn = 'Bianco e nero', firma = 'Firma e copyright' }
local ORDINE = { 'stile', 'bianco', 'tono', 'raddrizza', 'bn', 'firma' }

function Lavoro.testo(r)
  local L = {}
  L[#L + 1] = string.format('%s %d foto su %d in %s.', r.prova and 'Prova finita:' or 'Fatto:', r.fatte, r.n, Lavoro.durata(r.durata))
  if r.interrotto then L[#L + 1] = 'Interrotto da te: le foto rimaste non sono state toccate.' end
  if (r.conti.riparti or 0) > 0 then
    L[#L + 1] = '• Foto della prova di prima ripartite da com\'erano: ' .. r.conti.riparti
  end
  for _, k in ipairs(ORDINE) do
    local n, e = r.conti[k], r.errori[k]
    if n > 0 or e then
      L[#L + 1] = '• ' .. NOMI[k] .. ': ' .. n .. ' foto' .. (e and string.format(' (%d errori, primo: %s)', e.n, tostring(e.primo):sub(1, 160)) or '')
    end
  end
  if r.erroriFoto and #r.erroriFoto > 0 then
    L[#L + 1] = string.format('• %d foto non toccate.%s', #r.erroriFoto, Core.primoErrore(r.erroriFoto))
  end
  if r.prova and #r.verifica > 0 then L[#L + 1] = 'Controllo: ' .. table.concat(r.verifica, '; ') .. '.' end
  if r.raccolta then L[#L + 1] = '\nLe trovi nella raccolta DZ Auto > ' .. r.raccolta .. '.' end
  if r.fatte > 0 then L[#L + 1] = 'Non ti piace? File > Extra plug-in > DZ Auto: Torna come prima.' end
  if r.risparmio > 0 then
    L[#L + 1] = string.format('\nTempo risparmiato (stima): circa %s con questo lavoro, circa %s in tutto.',
      Core.testoDurata(r.risparmio), Core.testoDurata(Core.prefs().risparmioSec))
  end
  if r.avviso and r.avviso ~= true then L[#L + 1] = 'Avviso sul telefono non partito: ' .. tostring(r.avviso) end
  return table.concat(L, '\n')
end

-- Torna come prima: rimette l'istantanea "prima" dell'ultimo lavoro.
function Lavoro.torna(context)
  local u = Lavoro.ultimo()
  if not u then
    LrDialogs.message('DZ Auto', 'Non c\'e un lavoro di DZ Auto da annullare.', 'info')
    return
  end
  local scelta = LrDialogs.confirm('Torna come prima?',
    string.format('Rimetto %d foto com\'erano prima di DZ Auto (lavoro del %s%s).\nOgni foto torna all\'istantanea "%s". La raccolta resta: puoi cancellarla tu.',
      #u.uuid, tostring(u.quando), u.prova and ', prova' or '', tostring(u.nome)),
    'Torna come prima', 'Annulla')
  if scelta ~= 'ok' then return end
  local catalog = LrApplication.activeCatalog()
  local lista = {}
  for _, id in ipairs(u.uuid) do
    local ok, f = Core.pcall(function() return catalog:findPhotoByUuid(id) end)
    if ok and f then lista[#lista + 1] = f end
  end
  local avanz = LrProgressScope { title = 'DZ Auto: torno come prima', functionContext = context }
  local fatti, errori = Core.aGruppi(catalog, 'DZ Auto: torna come prima', lista, Lavoro.GRUPPO, function(f)
    Lavoro.applicaIstantanea(f, u.nome)
  end, avanz)
  avanz:done()
  Core.log(string.format('Torna come prima: %d di %d', fatti, #u.uuid))
  local msg = string.format('Rimesse come prima: %d foto su %d.', fatti, #u.uuid)
  if #lista < #u.uuid then msg = msg .. string.format(' %d foto non sono piu nel catalogo.', #u.uuid - #lista) end
  if #errori > 0 then msg = msg .. string.format(' %d errori.', #errori) .. Core.primoErrore(errori) end
  LrDialogs.message('DZ Auto', msg, #errori > 0 and 'warning' or 'info')
end

return Lavoro
