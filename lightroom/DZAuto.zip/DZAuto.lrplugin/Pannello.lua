-- DZ Auto 2.0 - idea e sviluppo by Daniel Zavan
-- Il pannello: una finestra con le schede Avvia, Scelta, Colore, Raddrizza e ritaglio, Bianco e nero, Altro.
-- Ogni voce ha una riga di spiegazione. Le scelte restano salvate. Tasti: AVVIA, Prova su 20 foto, Chiudi.

local LrBinding = import 'LrBinding'
local LrDialogs = import 'LrDialogs'
local LrHttp = import 'LrHttp'
local LrTasks = import 'LrTasks'
local LrView = import 'LrView'

local Core = require 'Core'
local Lavoro = require 'Lavoro'
local Aggiorna = require 'Aggiorna'
local Aiuto = require 'Aiuto'

local Pannello = {}
local NESSUNO = '-'
local LARGO = 66

local function spiega(f, testo, righe)
  return f:static_text { title = testo, width_in_chars = LARGO, height_in_lines = righe or 2, font = '<system/small>' }
end

local function titolo(f, testo)
  return f:static_text { title = testo, font = '<system/bold>', width_in_chars = LARGO }
end

local function voce(f, chiave, nome, testo, righe)
  return f:column {
    spacing = f:label_spacing(),
    f:checkbox { title = nome, value = LrView.bind(chiave), font = '<system/bold>' },
    f:row { f:spacer { width = 20 }, f:static_text { title = testo, width_in_chars = LARGO - 4, height_in_lines = righe or 2, font = '<system/small>' } }
  }
end

local function riga(f, nome, controllo)
  return f:row { f:static_text { title = nome, width_in_chars = 22, alignment = 'right' }, controllo }
end

-- Mostra il pannello. Ritorna 'avvia', 'prova' oppure nil, e le scelte aggiornate (gia salvate).
function Pannello.mostra(context, dati, o)
  local f = LrView.osFactory()
  local props = LrBinding.makePropertyTable(context)
  local p = Core.prefs()

  local elenco = Core.preset()
  local esiste = {}
  for _, pr in ipairs(elenco) do esiste[pr.uuid] = true end
  local function voci(primo)
    local v = { { title = primo, value = NESSUNO } }
    for _, pr in ipairs(elenco) do v[#v + 1] = { title = pr.titolo, value = pr.uuid } end
    return v
  end
  local function valido(u, riserva)
    if u and esiste[u] then return u end
    return riserva or NESSUNO
  end

  -- Fotocamere ed etichette delle foto di adesso.
  local modelli, conta = Core.modelli(dati)
  if #modelli == 0 then
    for m in pairs(o.stile) do modelli[#modelli + 1] = m end
    table.sort(modelli)
  end
  local perEtichetta, scelte = {}, 0
  for _, d in ipairs(dati) do
    perEtichetta[d.etichetta] = (perEtichetta[d.etichetta] or 0) + 1
    if d.scelta then scelte = scelte + 1 end
  end

  props.colore, props.bianco, props.tono, props.forza = o.colore, o.bianco, o.tono, o.forza
  props.autoPreset = valido(o.autoPreset, Lavoro.cercaPreset(Lavoro.NOMI_AUTO, elenco, true))
  props.raddrizza = o.raddrizza
  props.bn, props.bnEtichetta = o.bn, o.bnEtichetta
  props.bnPreset = valido(o.bnPreset, Lavoro.cercaPreset(Lavoro.NOMI_BN, elenco))
  props.firma, props.soloScelte, props.avviso, props.mostra = o.firma, o.soloScelte, o.avviso, o.mostra
  props.firmaAutore, props.firmaCopyright, props.firmaEmail, props.firmaSito, props.firmaTelefono =
    p.firmaAutore, p.firmaCopyright, p.firmaEmail, p.firmaSito, p.firmaTelefono
  for i, m in ipairs(modelli) do props['stile' .. i] = valido(o.stile[m]) end
  props.aggStato = Aggiorna.testo(nil, false):gsub('Non riesco.*', 'Controllo gli aggiornamenti...')
  props.aggPronto = false
  props.aiutoStato = ''

  -- Intestazione della scheda Avvia.
  local parti = {}
  for _, m in ipairs(modelli) do
    if conta[m] then parti[#parti + 1] = m .. ': ' .. conta[m] end
  end
  local intestazione = string.format('%d foto', #dati) .. (#parti > 0 and (' · ' .. table.concat(parti, ' · ')) or '')
  local sotto = 'Lavora sulle foto selezionate (se ne selezioni piu di una) oppure su tutte quelle visibili. In ordine di scatto.'
  if scelte > 0 then sotto = sotto .. ' Con la bandierina "scelta": ' .. scelte .. '.' end

  local avvia = f:tab_view_item {
    title = 'Avvia', identifier = 'avvia',
    f:column {
      spacing = f:control_spacing(),
      titolo(f, intestazione),
      spiega(f, sotto, 2),
      f:separator { fill_horizontal = 1 },
      voce(f, 'colore', 'Colore: il tuo stile + correzione foto per foto', 'Il preset di ogni fotocamera, poi bianco ed esposizione automatici. Dettagli nella scheda Colore.'),
      voce(f, 'raddrizza', 'Raddrizza', 'Lightroom raddrizza le foto storte (Upright "Livello"). Scheda Raddrizza e ritaglio.', 1),
      voce(f, 'bn', 'Bianco e nero sulle foto che segni tu', 'Metti l\'etichetta colore alle foto da fare in bianco e nero (es. Blu, tasto 9). Scheda Bianco e nero.'),
      voce(f, 'firma', 'Firma e copyright', 'Scrive autore e copyright nelle foto. Scheda Altro.', 1),
      voce(f, 'avviso', 'Mail sull\'iPhone alla fine', 'Puoi alzarti dal Mac: quando ha finito ti arriva la mail.', 1),
      f:separator { fill_horizontal = 1 },
      spiega(f, 'Sicuro: prima di toccare una foto DZ Auto salva l\'istantanea "prima". Per annullare tutto: File > Extra plug-in > DZ Auto: Torna come prima. I file originali non vengono mai modificati.', 3),
      spiega(f, 'Prima volta su un servizio? Premi "Prova su ' .. Lavoro.PROVA .. ' foto": lavora su poche foto sparse e ti dice com\'e andata.', 2),
      f:static_text { title = Core.testoRisparmio(), width_in_chars = LARGO, font = '<system/small>' },
      f:static_text { title = LrView.bind('aggStato'), width_in_chars = LARGO, font = '<system/small>' },
      f:static_text { title = LrView.bind('aiutoStato'), width_in_chars = LARGO, font = '<system/bold>' }
    }
  }

  local scelta = f:tab_view_item {
    title = 'Scelta', identifier = 'scelta',
    f:column {
      spacing = f:control_spacing(),
      titolo(f, 'Scelta delle foto'),
      voce(f, 'soloScelte', 'Lavora solo sulle foto con la bandierina "scelta"', 'Utile se prima scegli le foto con la Selezione assistita di Lightroom o a mano (tasto P).'),
      spiega(f, 'Selezione assistita di Lightroom (gia nella tua versione, Assisted Culling): menu Lightroom Classic > Impostazioni catalogo > Metadati, attivala. Nel modulo Libreria, pannello Selezione assistita: soggetto a fuoco, occhi a fuoco, occhi aperti; scarta esposizione sbagliata e scatti a vuoto. Poi Organizza risultati > Applica azioni > Applica bandierina: Scelta (Pick). Non usare Elimina.', 5),
      f:separator { fill_horizontal = 1 },
      titolo(f, 'Scelta automatica di DZ Auto: in arrivo'),
      spiega(f, 'DZ Auto scegliera da solo la foto migliore di ogni raffica e segnera occhi chiusi e foto mosse, con il riconoscimento del Mac (gratis, le foto non escono dal Mac). Arriva dopo una prova sul tuo Mac.', 3)
    }
  }

  local righeColore = {
    spacing = f:control_spacing(),
    titolo(f, 'Il tuo stile'),
    spiega(f, 'Per ogni fotocamera scegli il tuo preset: DZ Auto lo applica a ogni foto.', 1)
  }
  for i, m in ipairs(modelli) do
    righeColore[#righeColore + 1] = riga(f, m .. (conta[m] and (' (' .. conta[m] .. ')') or ''),
      f:popup_menu { items = voci('(nessun preset)'), value = LrView.bind('stile' .. i), width_in_chars = 38, enabled = LrView.bind('colore') })
  end
  righeColore[#righeColore + 1] = riga(f, 'Forza del tuo stile', f:row {
    f:slider { value = LrView.bind('forza'), min = 0, max = 200, integral = true, width_in_chars = 26, enabled = LrView.bind('colore') },
    f:static_text { title = LrView.bind { key = 'forza', transform = function(v) return string.format('%d%%', tonumber(v) or 100) end }, width_in_chars = 6 }
  })
  righeColore[#righeColore + 1] = spiega(f, '100% = come il tuo preset. Meno = piu delicato, piu = piu marcato.', 1)
  righeColore[#righeColore + 1] = voce(f, 'bianco', 'Bianco automatico, foto per foto', 'Toglie le dominanti: luci calde in chiesa, ombre blu all\'aperto.', 1)
  righeColore[#righeColore + 1] = voce(f, 'tono', 'Esposizione e contrasto automatici', 'Lightroom regola esposizione, contrasto, luci, ombre, bianchi e neri (e un poco vividezza e saturazione). Curve e profilo restano quelli del tuo preset.', 3)
  righeColore[#righeColore + 1] = riga(f, 'Preset "Automatico"',
    f:popup_menu { items = voci('(manca: crealo, vedi sotto)'), value = LrView.bind('autoPreset'), width_in_chars = 38, enabled = LrView.bind('tono') })
  righeColore[#righeColore + 1] = spiega(f, 'Il preset "Automatico" si crea una volta sola: modulo Sviluppo > pannello Preset > + > Crea preset. Nome: Automatico. Premi "Nessuno" (Check None), poi spunta solo "Impostazioni automatiche" (Auto Settings) e premi Crea. Riapri questo pannello e sceglilo qui.', 4)
  righeColore[#righeColore + 1] = spiega(f, 'Ordine: prima il tuo preset, poi la correzione. Cosi ogni foto parte giusta e lo stile resta il tuo.', 2)
  local colore = f:tab_view_item { title = 'Colore', identifier = 'colore', f:column(righeColore) }

  local raddrizza = f:tab_view_item {
    title = 'Raddrizza e ritaglio', identifier = 'raddrizza',
    f:column {
      spacing = f:control_spacing(),
      voce(f, 'raddrizza', 'Raddrizza le foto storte', 'Usa Upright "Livello" di Lightroom: raddrizza l\'orizzonte e taglia i bordi bianchi. Se una foto non ti piace: modulo Sviluppo, pannello Trasforma, togli Upright.', 3),
      f:separator { fill_horizontal = 1 },
      titolo(f, 'Ritaglio sui soggetti (primi piani): in arrivo'),
      spiega(f, 'Con il riconoscimento dei volti del Mac DZ Auto ritagliera i primi piani tenendo il formato, con i volti sui terzi. Le panoramiche saranno solo raddrizzate. Arriva dopo la prova sul tuo Mac.', 3)
    }
  }

  local bn = f:tab_view_item {
    title = 'Bianco e nero', identifier = 'bn',
    f:column {
      spacing = f:control_spacing(),
      voce(f, 'bn', 'Bianco e nero sulle foto che segni tu', 'Nel modulo Libreria metti l\'etichetta colore alle foto da fare in bianco e nero (es. tasto 9 = Blu). DZ Auto ci mette il tuo preset bianco e nero al posto dello stile a colori.', 3),
      riga(f, 'Etichetta', f:popup_menu { items = Core.ETICHETTE, value = LrView.bind('bnEtichetta'), width_in_chars = 20, enabled = LrView.bind('bn') }),
      riga(f, 'Preset bianco e nero', f:popup_menu { items = voci('(scegli il preset)'), value = LrView.bind('bnPreset'), width_in_chars = 38, enabled = LrView.bind('bn') }),
      f:static_text {
        title = LrView.bind { key = 'bnEtichetta', transform = function(v)
          return 'Adesso: ' .. (perEtichetta[v] or 0) .. ' foto con etichetta ' .. Core.nomeEtichetta(v) .. '.'
        end },
        width_in_chars = LARGO, font = '<system/small>'
      }
    }
  }

  local function campo(nome, chiave)
    return riga(f, nome, f:edit_field { value = LrView.bind(chiave), width_in_chars = 36 })
  end
  local altro = f:tab_view_item {
    title = 'Altro', identifier = 'altro',
    f:column {
      spacing = f:control_spacing(),
      titolo(f, 'Firma e copyright'),
      campo('Autore', 'firmaAutore'), campo('Copyright', 'firmaCopyright'), campo('Mail', 'firmaEmail'),
      campo('Sito', 'firmaSito'), campo('Telefono', 'firmaTelefono'),
      f:separator { fill_horizontal = 1 },
      voce(f, 'mostra', 'Alla fine mostra la raccolta con le foto lavorate', 'DZ Auto mette le foto lavorate nella raccolta DZ Auto > data e nome, e la apre.', 1),
      f:separator { fill_horizontal = 1 },
      titolo(f, 'Aiuto e messaggi'),
      spiega(f, 'La tua pagina: scrivi problemi, domande e idee, allega file e schermate. Li leggiamo e ti rispondiamo li; versioni nuove e istruzioni arrivano li, con una mail.', 2),
      f:row {
        f:push_button { title = 'AIUTO E MESSAGGI', action = function() LrTasks.startAsyncTask(function() Aiuto.apri() end) end }
      },
      spiega(f, 'Segnalazione con riepilogo, diagnostica e schermata del Mac: File > Extra plug-in > DZ Auto: Manda segnalazione.', 1),
      f:separator { fill_horizontal = 1 },
      titolo(f, 'Aggiornamenti'),
      f:static_text { title = LrView.bind('aggStato'), width_in_chars = LARGO, height_in_lines = 2, font = '<system/small>' },
      f:row {
        f:push_button {
          title = 'CONTROLLA',
          action = function()
            LrTasks.startAsyncTask(function()
              props.aggStato = 'Controllo...'
              local v, nuova = Aggiorna.controlla(true)
              props.aggStato = Aggiorna.testo(v, nuova)
              props.aggPronto = nuova and true or false
            end)
          end
        },
        f:push_button {
          title = 'AGGIORNA ORA', enabled = LrView.bind('aggPronto'),
          action = function()
            LrTasks.startAsyncTask(function()
              props.aggStato = 'Scarico e installo...'
              props.aggPronto = false
              local ok, m = Aggiorna.installa()
              props.aggStato = ok and ('Fatto: versione ' .. m .. ' installata. Chiudi e riapri Lightroom per usarla.') or ('Non riuscito: ' .. tostring(m))
            end)
          end
        }
      },
      f:separator { fill_horizontal = 1 },
      f:row {
        f:push_button { title = 'Guida', action = function() LrHttp.openUrlInBrowser(Core.GUIDA) end },
        f:push_button {
          title = 'Aiuto e messaggi',
          action = function()
            LrTasks.startAsyncTask(function() require('Aiuto').apri() end)
          end
        }
      },
      spiega(f, Core.statoLicenza() .. ' Chiave, avvisi, orologi e diagnostica: File > Gestione plug-in > DZ Auto. Allinea orologi ed Esporta consegna: File > Extra plug-in.', 3),
      f:static_text { title = 'DZ Auto ' .. Core.VERSIONE .. ' - idea e sviluppo by Daniel Zavan', font = '<system/small>' }
    }
  }

  local contenuto = f:column {
    bind_to_object = props,
    f:tab_view { value = LrView.bind('scheda'), avvia, scelta, colore, raddrizza, bn, altro }
  }
  props.scheda = 'avvia'

  LrTasks.startAsyncTask(function()
    local v, nuova = Aggiorna.controlla(false)
    props.aggStato = Aggiorna.testo(v, nuova)
    props.aggPronto = nuova and true or false
    local r = Aiuto.chiedi()
    if r and tonumber(r.nuovi) and tonumber(r.nuovi) > 0 then
      props.aiutoStato = 'Hai ' .. r.nuovi .. (tonumber(r.nuovi) == 1 and ' messaggio nuovo' or ' messaggi nuovi') .. ' da DZ Auto: scheda Altro > AIUTO E MESSAGGI.'
    end
  end)

  local esito = LrDialogs.presentModalDialog {
    title = 'DZ Auto · Pannello',
    contents = contenuto,
    actionVerb = 'AVVIA',
    otherVerb = 'Prova su ' .. math.min(Lavoro.PROVA, math.max(#dati, 1)) .. ' foto',
    cancelVerb = 'Chiudi',
    save_frame = 'dzautoPannello'
  }

  -- Le scelte restano salvate anche con Chiudi.
  o.colore, o.bianco, o.tono = props.colore == true, props.bianco == true, props.tono == true
  o.forza = math.max(0, math.min(200, math.floor(tonumber(props.forza) or 100)))
  o.autoPreset = props.autoPreset ~= NESSUNO and props.autoPreset or nil
  o.raddrizza = props.raddrizza == true
  o.bn, o.bnEtichetta = props.bn == true, props.bnEtichetta or 'blue'
  o.bnPreset = props.bnPreset ~= NESSUNO and props.bnPreset or nil
  o.firma, o.soloScelte, o.avviso, o.mostra = props.firma == true, props.soloScelte == true, props.avviso == true, props.mostra == true
  for i, m in ipairs(modelli) do
    local v = props['stile' .. i]
    o.stile[m] = (v and v ~= NESSUNO) and v or nil
  end
  Lavoro.salva(o)
  p.firmaAutore, p.firmaCopyright, p.firmaEmail, p.firmaSito, p.firmaTelefono =
    props.firmaAutore, props.firmaCopyright, props.firmaEmail, props.firmaSito, props.firmaTelefono

  if esito == 'ok' then return 'avvia', o end
  if esito == 'other' then return 'prova', o end
  return nil, o
end

return Pannello
