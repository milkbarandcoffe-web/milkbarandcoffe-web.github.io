-- DZ Auto 2.0 - idea e sviluppo by Daniel Zavan
-- File > Extra plug-in > DZ Auto: Torna come prima. Annulla l'ultimo lavoro (istantanea "prima").

local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrTasks = import 'LrTasks'

local Lavoro = require 'Lavoro'

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto torna come prima', function(context)
    LrDialogs.attachErrorDialogToFunctionContext(context)
    Lavoro.torna(context)
  end)
end)
