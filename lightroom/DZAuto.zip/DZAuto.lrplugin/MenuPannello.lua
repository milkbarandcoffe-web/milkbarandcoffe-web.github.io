-- DZ Auto 2.0 - idea e sviluppo by Daniel Zavan
-- File > Extra plug-in > DZ Auto: Pannello. Apre il pannello; AVVIA o Prova lavorano sulle foto.

local LrApplication = import 'LrApplication'
local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrTasks = import 'LrTasks'

local Core = require 'Core'
local Lavoro = require 'Lavoro'
local Pannello = require 'Pannello'

local function apri(context)
  LrDialogs.attachErrorDialogToFunctionContext(context)
  local catalog = LrApplication.activeCatalog()
  local o = Lavoro.opzioni()
  -- Dopo un problema o "Torna al pannello" il pannello si riapre (al massimo 10 volte).
  for _ = 1, 10 do
    local azione
    azione, o = Pannello.mostra(context, Lavoro.foto(catalog, nil), o)
    if not azione then return end
    local prova = azione == 'prova'
    local sel = Lavoro.foto(catalog, o)
    if prova then sel = Lavoro.campione(sel, Lavoro.PROVA) end
    local _, problemi, avvisi = Lavoro.piano(o, sel)
    if #problemi > 0 then
      LrDialogs.message('DZ Auto', table.concat(problemi, '\n'), 'warning')
    else
      local ok, motivo = Core.licenza(false)
      if not ok then
        LrDialogs.message('DZ Auto', motivo, 'warning')
        return
      end
      local via = #avvisi == 0 or LrDialogs.confirm('DZ Auto: prima di partire',
        table.concat(avvisi, '\n') .. '\n\nContinuo lo stesso?', 'Continua', 'Torna al pannello') == 'ok'
      if via then
        local r = Lavoro.esegui(context, o, sel, prova)
        Lavoro.mostraFine(r)
        return
      end
    end
  end
end

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto pannello', apri)
end)
