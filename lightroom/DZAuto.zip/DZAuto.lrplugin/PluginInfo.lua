-- DZ Auto - idea e sviluppo by Daniel
-- Riquadri in File > Gestione plug-in > DZ Auto: chiave, firma e copyright, avvisi, orologi, diagnostica.

local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrHttp = import 'LrHttp'
local LrTasks = import 'LrTasks'
local LrView = import 'LrView'

local Core = require 'Core'

local function sezioni(f, props)
  local p = Core.prefs()
  props.statoChiave = p.licOk and Core.statoLicenza() or 'Scrivi la chiave e premi VERIFICA.'
  props.statoAvviso = ''
  props.scarti = Core.testoScarti()

  local function verifica()
    LrTasks.startAsyncTask(function()
      props.statoChiave = 'Controllo...'
      local ok, motivo = Core.licenza(true)
      props.statoChiave = ok and Core.statoLicenza() or motivo
    end)
  end

  return {
    {
      title = 'DZ Auto: chiave',
      bind_to_object = p,
      f:row {
        f:static_text { title = 'Chiave:', width_in_chars = 14 },
        f:edit_field { value = LrView.bind('chiave'), width_in_chars = 22, immediate = true },
        f:push_button { title = 'VERIFICA', action = verifica }
      },
      f:static_text { title = LrView.bind { key = 'statoChiave', bind_to_object = props }, width_in_chars = 60, height_in_lines = 2 },
      f:row {
        f:push_button { title = 'Guida', action = function() LrHttp.openUrlInBrowser(Core.GUIDA) end },
        f:push_button {
          title = 'Domande e suggerimenti',
          action = function()
            LrTasks.startAsyncTask(function()
              local c = Core.config(false)
              LrHttp.openUrlInBrowser((type(c) == 'table' and c.domande) or Core.GUIDA)
            end)
          end
        }
      }
    },
    {
      title = 'DZ Auto: firma e copyright',
      bind_to_object = p,
      f:static_text { title = 'Scritti nelle foto con "Firma e copyright" e prima di ogni "Esporta consegna".' },
      f:row { f:static_text { title = 'Autore:', width_in_chars = 14 }, f:edit_field { value = LrView.bind('firmaAutore'), width_in_chars = 36 } },
      f:row { f:static_text { title = 'Copyright:', width_in_chars = 14 }, f:edit_field { value = LrView.bind('firmaCopyright'), width_in_chars = 36 } },
      f:row { f:static_text { title = 'Mail:', width_in_chars = 14 }, f:edit_field { value = LrView.bind('firmaEmail'), width_in_chars = 36 } },
      f:row { f:static_text { title = 'Sito:', width_in_chars = 14 }, f:edit_field { value = LrView.bind('firmaSito'), width_in_chars = 36 } },
      f:row { f:static_text { title = 'Telefono:', width_in_chars = 14 }, f:edit_field { value = LrView.bind('firmaTelefono'), width_in_chars = 36 } }
    },
    {
      title = 'DZ Auto: avvisi e orologi',
      f:row {
        f:push_button {
          title = 'PROVA AVVISO',
          action = function()
            LrTasks.startAsyncTask(function()
              props.statoAvviso = 'Invio...'
              local ok, m = Core.avviso('Prova avviso', 'Se leggi questo messaggio, gli avvisi di DZ Auto funzionano.')
              props.statoAvviso = ok and 'Inviato: controlla la mail sul telefono.' or tostring(m)
            end)
          end
        },
        f:static_text { title = LrView.bind { key = 'statoAvviso', bind_to_object = props }, width_in_chars = 44 }
      },
      f:static_text { title = LrView.bind { key = 'scarti', bind_to_object = props }, width_in_chars = 60, height_in_lines = 2 },
      f:push_button {
        title = 'AZZERA OROLOGI',
        action = function()
          p.scarti = {}
          p.scartiQuando = nil
          props.scarti = Core.testoScarti()
        end
      }
    },
    {
      title = 'DZ Auto: diagnostica (versione ' .. Core.VERSIONE .. ')',
      f:static_text { title = 'Se qualcosa non va: MOSTRA DIAGNOSTICA, copia il testo e mandalo con "Domande e suggerimenti".' },
      f:push_button {
        title = 'MOSTRA DIAGNOSTICA',
        action = function()
          LrFunctionContext.callWithContext('DZ Auto diagnostica', function()
            local t = 'DZ Auto ' .. Core.VERSIONE .. '\n' .. Core.statoLicenza() .. '\n' .. Core.testoScarti() .. '\n\n' .. (p.diagnostica or '(vuota)')
            local f2 = LrView.osFactory()
            LrDialogs.presentModalDialog {
              title = 'DZ Auto: diagnostica',
              contents = f2:edit_field { value = t, width_in_chars = 80, height_in_lines = 20 },
              cancelVerb = '< exclude >',
              actionVerb = 'Chiudi'
            }
          end)
        end
      },
      f:static_text { title = 'DZ Auto - idea e sviluppo by Daniel Zavan' }
    }
  }
end

return {
  sectionsForTopOfDialog = sezioni
}
