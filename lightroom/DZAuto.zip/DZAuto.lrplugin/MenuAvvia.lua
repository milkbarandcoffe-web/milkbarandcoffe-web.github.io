-- DZ Auto 2.0 - idea e sviluppo by Daniel Zavan
-- File > Extra plug-in > DZ Auto: Avvia con le ultime scelte. Senza aprire il pannello.

local LrApplication = import 'LrApplication'
local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrTasks = import 'LrTasks'

local Core = require 'Core'
local Lavoro = require 'Lavoro'

local function avvia(context)
  LrDialogs.attachErrorDialogToFunctionContext(context)
  local catalog = LrApplication.activeCatalog()
  local o = Lavoro.opzioni()
  local sel = Lavoro.foto(catalog, o)
  local righe, problemi, avvisi = Lavoro.piano(o, sel)
  if #problemi > 0 then
    LrDialogs.message('DZ Auto', table.concat(problemi, '\n'), 'warning')
    return
  end
  local ok, motivo = Core.licenza(false)
  if not ok then
    LrDialogs.message('DZ Auto', motivo, 'warning')
    return
  end
  local testo = string.format('Lavoro su %d foto con le ultime scelte:\n• %s', #sel, table.concat(righe, '\n• '))
  if #avvisi > 0 then testo = testo .. '\n\n' .. table.concat(avvisi, '\n') end
  if LrDialogs.confirm('DZ Auto: avvio?', testo, 'AVVIA', 'Annulla') ~= 'ok' then return end
  local r = Lavoro.esegui(context, o, sel, false)
  LrDialogs.message('DZ Auto: fatto', Lavoro.testo(r), (next(r.errori) or #(r.erroriFoto or {}) > 0) and 'warning' or 'info')
end

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto avvia', avvia)
end)
