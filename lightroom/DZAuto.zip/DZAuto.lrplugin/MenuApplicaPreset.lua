-- DZ Auto - idea e sviluppo by Daniel
-- Applica preset: un preset per ogni fotocamera (D850, Z6 II...) alle foto selezionate o a tutte quelle visibili.

local LrApplication = import 'LrApplication'
local LrBinding = import 'LrBinding'
local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrProgressScope = import 'LrProgressScope'
local LrTasks = import 'LrTasks'
local LrView = import 'LrView'

local Core = require 'Core'

local NESSUNO = '-'

local function applica(context)
  LrDialogs.attachErrorDialogToFunctionContext(context)
  local ok, motivo = Core.licenza(false)
  if not ok then
    LrDialogs.message('DZ Auto', motivo, 'warning')
    return
  end

  local catalog = LrApplication.activeCatalog()
  local foto = catalog:getTargetPhotos()
  if #foto == 0 then
    LrDialogs.message('DZ Auto', 'Nessuna foto: apri una cartella o una raccolta.', 'info')
    return
  end

  local dati = Core.datiScatto(catalog, foto)
  local modelli, conta = Core.modelli(dati)
  local preset = Core.preset()
  if #preset == 0 then
    LrDialogs.message('DZ Auto', 'Non trovo preset di sviluppo in Lightroom.', 'warning')
    return
  end

  local voci = { { title = '(non cambiare)', value = NESSUNO } }
  for _, pr in ipairs(preset) do voci[#voci + 1] = { title = pr.titolo, value = pr.uuid } end

  local p = Core.prefs()
  local ultimi = p.presetPerCamera or {}
  local props = LrBinding.makePropertyTable(context)
  props.soloScelte = p.presetSoloScelte == true

  local f = LrView.osFactory()
  local righe = {
    f:static_text { title = string.format('%d foto. Scegli il preset per ogni fotocamera:', #foto) }
  }
  for i, m in ipairs(modelli) do
    local esiste = false
    for _, pr in ipairs(preset) do if pr.uuid == ultimi[m] then esiste = true end end
    props['p' .. i] = esiste and ultimi[m] or NESSUNO
    righe[#righe + 1] = f:row {
      f:static_text { title = string.format('%s (%d)', m, conta[m]), width_in_chars = 24 },
      f:popup_menu { items = voci, value = LrView.bind('p' .. i), width_in_chars = 36 }
    }
  end
  righe[#righe + 1] = f:checkbox { title = 'Solo le foto scelte (bandierina)', value = LrView.bind('soloScelte') }
  righe[#righe + 1] = f:static_text { title = 'Consiglio: prova prima su poche foto selezionate.' }
  righe.bind_to_object = props
  righe.spacing = f:control_spacing()

  local esito = LrDialogs.presentModalDialog {
    title = 'DZ Auto: applica preset',
    contents = f:column(righe),
    actionVerb = 'Applica'
  }
  if esito ~= 'ok' then return end

  local mappa, nuovi, almeno = {}, {}, false
  for k, v in pairs(ultimi) do nuovi[k] = v end
  for i, m in ipairs(modelli) do
    local v = props['p' .. i]
    if v and v ~= NESSUNO then
      mappa[m] = LrApplication.developPresetByUuid(v)
      nuovi[m] = v
      almeno = true
    end
  end
  p.presetPerCamera = nuovi
  p.presetSoloScelte = props.soloScelte
  if not almeno then return end

  local lista = {}
  for _, d in ipairs(dati) do
    if mappa[d.modello] and (not props.soloScelte or d.scelta) then lista[#lista + 1] = d end
  end
  if #lista == 0 then
    LrDialogs.message('DZ Auto', 'Nessuna foto da sistemare con queste scelte.', 'info')
    return
  end

  local avanz = LrProgressScope { title = 'DZ Auto: applico i preset', functionContext = context }
  Core.log(string.format('Applica preset: %d foto', #lista))
  local fatti, errori = Core.aGruppi(catalog, 'DZ Auto: applica preset', lista, 10, function(d)
    d.foto:applyDevelopPreset(mappa[d.modello], _PLUGIN)
  end, avanz)
  avanz:done()

  for _, e in ipairs(errori) do Core.log('Errore preset: ' .. e) end
  local msg = string.format('Preset applicati a %d foto.', fatti)
  if #errori > 0 then msg = msg .. string.format(' %d errori: vedi la diagnostica (File > Gestione plug-in > DZ Auto).', #errori) end
  if avanz:isCanceled() then msg = msg .. ' Interrotto.' end
  LrDialogs.message('DZ Auto', msg, #errori > 0 and 'warning' or 'info')
end

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto applica preset', applica)
end)
