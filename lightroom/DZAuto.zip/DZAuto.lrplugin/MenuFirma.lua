-- DZ Auto - idea e sviluppo by Daniel
-- Firma e copyright: autore, copyright e contatti (da File > Gestione plug-in > DZ Auto) nelle foto selezionate o visibili.

local LrApplication = import 'LrApplication'
local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrProgressScope = import 'LrProgressScope'
local LrTasks = import 'LrTasks'

local Core = require 'Core'

local function firma(context)
  LrDialogs.attachErrorDialogToFunctionContext(context)
  local ok, motivo = Core.licenza(false)
  if not ok then
    LrDialogs.message('DZ Auto', motivo, 'warning')
    return
  end
  if not Core.firmaPronta() then
    LrDialogs.message('DZ Auto', 'Prima scrivi autore e copyright: File > Gestione plug-in > DZ Auto, riquadro "Firma e copyright".', 'info')
    return
  end

  local catalog = LrApplication.activeCatalog()
  local foto = catalog:getTargetPhotos()
  if #foto == 0 then return end
  if LrDialogs.confirm('DZ Auto: firma e copyright', string.format('Scrivo la firma in %d foto?', #foto), 'Scrivi', 'Annulla') ~= 'ok' then
    return
  end

  local avanz = LrProgressScope { title = 'DZ Auto: firma e copyright', functionContext = context }
  local fatti, errori = Core.aGruppi(catalog, 'DZ Auto: firma', foto, 50, Core.scriviFirma, avanz)
  avanz:done()
  for _, e in ipairs(errori) do Core.log('Errore firma: ' .. e) end
  if fatti > 0 then Core.conta('firma', fatti) end
  LrDialogs.message('DZ Auto', string.format('Firma scritta in %d foto.', fatti) ..
    (#errori > 0 and string.format(' %d errori: vedi la diagnostica.', #errori) or '') ..
    '\n\n' .. Core.testoRisparmio(), #errori > 0 and 'warning' or 'info')
end

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto firma', firma)
end)
