-- DZ Auto - idea e sviluppo by Daniel
-- Finestra "Esporta consegna".

local LrApplication = import 'LrApplication'
local LrBinding = import 'LrBinding'
local LrDialogs = import 'LrDialogs'
local LrFileUtils = import 'LrFileUtils'
local LrFunctionContext = import 'LrFunctionContext'
local LrShell = import 'LrShell'
local LrTasks = import 'LrTasks'
local LrView = import 'LrView'

local Core = require 'Core'
local Esporta = require 'Esporta'

local function finestra(context)
  LrDialogs.attachErrorDialogToFunctionContext(context)
  local ok, motivo = Core.licenza(false)
  if not ok then
    LrDialogs.message('DZ Auto', motivo, 'warning')
    return
  end

  local catalog = LrApplication.activeCatalog()
  local foto = catalog:getTargetPhotos()
  if #foto == 0 then
    LrDialogs.message('DZ Auto', 'Nessuna foto: apri la cartella o la raccolta del servizio.', 'info')
    return
  end
  local dati = Core.datiScatto(catalog, foto)
  local scelte = 0
  for _, d in ipairs(dati) do if d.scelta then scelte = scelte + 1 end end

  local p = Core.prefs()
  local props = LrBinding.makePropertyTable(context)
  props.base = p.espBase or ''
  props.cartella = p.espCartella or ''
  props.quali = (scelte > 0) and 'scelte' or 'tutte'
  props.alta = p.espAlta ~= false
  props.web = p.espWeb ~= false
  props.filigrana = p.espFiligrana or 'nessuna'
  props.firma = p.espFirma ~= false
  props.avviso = p.espAvviso ~= false

  local filigrane = Core.filigrane()
  local vociF = { { title = 'Copyright semplice (dal campo copyright)', value = Core.FILIGRANA_COPYRIGHT } }
  for _, w in ipairs(filigrane) do vociF[#vociF + 1] = { title = w.titolo, value = w.id } end
  props.filigranaId = p.espFiligranaId or Core.FILIGRANA_COPYRIGHT
  local trovata = false
  for _, v in ipairs(vociF) do if v.value == props.filigranaId then trovata = true end end
  if not trovata then props.filigranaId = Core.FILIGRANA_COPYRIGHT end

  local f = LrView.osFactory()
  local contenuto = f:column {
    bind_to_object = props,
    spacing = f:control_spacing(),
    f:row {
      f:static_text { title = 'Nome del servizio:', width_in_chars = 18 },
      f:edit_field { value = LrView.bind('base'), width_in_chars = 30, immediate = true }
    },
    f:static_text { title = 'I file si chiameranno Nome_0001.jpg, Nome_0002.jpg... in ordine di scatto.' },
    f:row {
      f:static_text { title = 'Cartella:', width_in_chars = 18 },
      f:static_text { title = LrView.bind('cartella'), width_in_chars = 30 },
      f:push_button {
        title = 'Scegli...',
        action = function()
          local r = LrDialogs.runOpenPanel { title = 'Cartella della consegna', canChooseFiles = false, canChooseDirectories = true, allowsMultipleSelection = false, canCreateDirectories = true }
          if r and r[1] then props.cartella = r[1] end
        end
      }
    },
    f:row {
      f:static_text { title = 'Foto:', width_in_chars = 18 },
      f:popup_menu {
        value = LrView.bind('quali'),
        items = {
          { title = string.format('Solo le scelte con la bandierina (%d)', scelte), value = 'scelte' },
          { title = string.format('Tutte quelle visibili (%d)', #foto), value = 'tutte' }
        }
      }
    },
    f:checkbox { title = 'Alta qualità (dimensione originale, JPEG 100%)', value = LrView.bind('alta') },
    f:checkbox { title = 'Web (lato lungo ' .. Esporta.WEB_LATO .. ' px, JPEG 80%)', value = LrView.bind('web') },
    f:row {
      f:static_text { title = 'Filigrana:', width_in_chars = 18 },
      f:popup_menu {
        value = LrView.bind('filigrana'),
        items = {
          { title = 'Nessuna', value = 'nessuna' },
          { title = 'Solo sulla versione web', value = 'web' },
          { title = 'Su tutte', value = 'tutte' }
        }
      }
    },
    f:row {
      f:static_text { title = 'Quale filigrana:', width_in_chars = 18 },
      f:popup_menu { value = LrView.bind('filigranaId'), items = vociF, width_in_chars = 30 }
    },
    f:checkbox { title = 'Scrivi firma e copyright prima di esportare', value = LrView.bind('firma') },
    f:checkbox { title = 'Avvisami sul telefono quando ha finito', value = LrView.bind('avviso') },
    f:static_text { title = 'Orologi: ' .. Core.testoScarti(), width_in_chars = 60, height_in_lines = 2 }
  }

  local esito = LrDialogs.presentModalDialog { title = 'DZ Auto: esporta consegna', contents = contenuto, actionVerb = 'Esporta' }
  if esito ~= 'ok' then return end

  p.espBase = props.base
  p.espCartella = props.cartella
  p.espAlta = props.alta
  p.espWeb = props.web
  p.espFiligrana = props.filigrana
  p.espFiligranaId = props.filigranaId
  p.espFirma = props.firma
  p.espAvviso = props.avviso

  if Core.trim(props.base) == '' then
    LrDialogs.message('DZ Auto', 'Scrivi il nome del servizio (per esempio Rossi).', 'warning')
    return
  end
  if props.cartella == '' or LrFileUtils.exists(props.cartella) ~= 'directory' then
    LrDialogs.message('DZ Auto', 'Scegli la cartella della consegna.', 'warning')
    return
  end
  if not props.alta and not props.web then
    LrDialogs.message('DZ Auto', 'Scegli almeno una versione: alta qualità o web.', 'warning')
    return
  end

  local lista = {}
  for _, d in ipairs(dati) do
    if props.quali == 'tutte' or d.scelta then lista[#lista + 1] = d end
  end
  if #lista == 0 then
    LrDialogs.message('DZ Auto', 'Nessuna foto con la bandierina. Scegli le foto (tasto P) oppure "Tutte quelle visibili".', 'info')
    return
  end
  Core.ordina(lista)

  local r = Esporta.esegui {
    catalog = catalog, dati = lista, base = props.base, cartella = props.cartella,
    alta = props.alta, web = props.web, filigrana = props.filigrana, filigranaId = props.filigranaId,
    firma = props.firma, context = context
  }
  local testo = Esporta.riepilogo(props.base, r)
  Core.log('Fine esportazione: ' .. testo)

  local nota = ''
  if props.avviso then
    local okA, msgA = Core.avviso('Esportazione finita', testo)
    if not okA then nota = '\n\n' .. tostring(msgA) end
  end
  if r.versioni[1] and LrFileUtils.exists(r.versioni[1].cartella) then
    pcall(LrShell.revealInShell, r.versioni[1].cartella)
  end
  LrDialogs.message('DZ Auto: consegna pronta', testo .. nota, #r.errori > 0 and 'warning' or 'info')
end

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto esporta', finestra)
end)
