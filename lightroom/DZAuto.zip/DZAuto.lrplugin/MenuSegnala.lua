-- DZ Auto 2.0.1 - idea e sviluppo by Daniel Zavan
-- File > Extra plug-in > DZ Auto: Manda segnalazione. Testo + riepilogo dell'ultimo lavoro + diagnostica + schermata.

local LrBinding = import 'LrBinding'
local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrTasks = import 'LrTasks'
local LrView = import 'LrView'

local Core = require 'Core'
local Aiuto = require 'Aiuto'

local function segnala(context)
  LrDialogs.attachErrorDialogToFunctionContext(context)
  local f = LrView.osFactory()
  local p = Core.prefs()
  local props = LrBinding.makePropertyTable(context)
  props.testo = ''
  props.riepilogo = p.ultimoRiepilogo ~= nil
  props.diagnostica = true
  props.schermata = p.segnalaSchermata ~= false
  local esito = LrDialogs.presentModalDialog {
    title = 'DZ Auto · Manda segnalazione',
    contents = f:column {
      bind_to_object = props,
      spacing = f:control_spacing(),
      f:static_text { title = 'Scrivi cosa succede o cosa vorresti. Arriva nella pagina Aiuto: la leggiamo e ti rispondiamo li.', width_in_chars = 56, height_in_lines = 2 },
      f:edit_field { value = LrView.bind('testo'), width_in_chars = 56, height_in_lines = 6 },
      f:checkbox { title = 'Allega il riepilogo dell\'ultimo lavoro', value = LrView.bind('riepilogo'), enabled = p.ultimoRiepilogo ~= nil },
      f:checkbox { title = 'Allega la diagnostica (cosa ha fatto DZ Auto, niente foto)', value = LrView.bind('diagnostica') },
      f:checkbox { title = 'Allega una schermata del Mac (si vede tutto lo schermo principale)', value = LrView.bind('schermata') },
      f:static_text { title = 'La prima volta il Mac chiede il permesso "Registrazione schermo" per Lightroom. Se dici di no, il resto parte lo stesso.', width_in_chars = 56, height_in_lines = 2, font = '<system/small>' }
    },
    actionVerb = 'Manda',
    cancelVerb = 'Annulla'
  }
  if esito ~= 'ok' then return end
  p.segnalaSchermata = props.schermata == true
  -- La finestra si chiude prima della schermata.
  LrTasks.sleep(1)
  local ok, nota = Aiuto.segnala({ testo = props.testo, riepilogo = props.riepilogo == true, diagnostica = props.diagnostica == true, schermata = props.schermata == true })
  if ok then
    LrDialogs.message('DZ Auto', 'Segnalazione mandata: grazie! La risposta arriva nella pagina Aiuto (File > Extra plug-in > DZ Auto: Aiuto e messaggi).' ..
      (nota and ('\n\nNota: ' .. tostring(nota)) or ''), 'info')
  else
    LrDialogs.message('DZ Auto', 'Segnalazione non mandata: ' .. tostring(nota) .. '\nPuoi scriverci dalla pagina Aiuto o su WhatsApp.', 'warning')
  end
end

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto segnalazione', segnala)
end)
