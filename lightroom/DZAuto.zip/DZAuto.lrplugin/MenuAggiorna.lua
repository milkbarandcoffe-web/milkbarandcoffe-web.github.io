-- DZ Auto 2.0 - idea e sviluppo by Daniel Zavan
-- File > Extra plug-in > DZ Auto: Aggiorna. Scarica e installa la versione nuova, se c'e.

local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrTasks = import 'LrTasks'

local Core = require 'Core'
local Aggiorna = require 'Aggiorna'

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto aggiorna', function(context)
    LrDialogs.attachErrorDialogToFunctionContext(context)
    local v, nuova = Aggiorna.controlla(true)
    if not nuova then
      LrDialogs.message('DZ Auto', Aggiorna.testo(v, false), 'info')
      return
    end
    if LrDialogs.confirm('DZ Auto: aggiornamento', 'C\'e la versione ' .. v .. ' (tu hai la ' .. Core.VERSIONE .. '). La installo adesso?', 'Aggiorna', 'Dopo') ~= 'ok' then return end
    local ok, m = Aggiorna.installa()
    if ok then
      LrDialogs.message('DZ Auto', 'Fatto: versione ' .. m .. ' installata. Chiudi e riapri Lightroom per usarla.', 'info')
    else
      LrDialogs.message('DZ Auto', 'Aggiornamento non riuscito: ' .. tostring(m) .. '\nPuoi sempre scaricarlo dalla guida.', 'warning')
    end
  end)
end)
