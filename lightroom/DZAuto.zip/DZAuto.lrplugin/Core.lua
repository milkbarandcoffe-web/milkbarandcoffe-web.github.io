-- DZ Auto - idea e sviluppo by Daniel
-- Funzioni comuni: preferenze, diagnostica, chiave, avvisi, tempo risparmiato, ordine di scatto, filigrane, lavori a gruppi.

local LrHttp = import 'LrHttp'
local LrPrefs = import 'LrPrefs'
local LrTasks = import 'LrTasks'
local LrFileUtils = import 'LrFileUtils'
local LrPathUtils = import 'LrPathUtils'
local LrLogger = import 'LrLogger'
local LrApplication = import 'LrApplication'

local Json = require 'Json'

local Core = {}
-- 1.1.1: pcall di Lightroom. I comandi di Lightroom (es. applica preset) aspettano Lightroom stesso (yield):
-- dentro il pcall di Lua danno "attempt to yield across metamethod/C-call boundary".
Core.pcall = (type(LrTasks.pcall) == 'function') and LrTasks.pcall or pcall

Core.VERSIONE = '1.1.1'
Core.LICENZE = 'https://script.google.com/macros/s/AKfycbyOMTa6oda0aBSEjd_AEK3Jjrd_IdzFrAlvQZ7BdW2HL7-4Lgb2XV_cphTm89NIqPttXQ/exec'
Core.CONFIG = 'https://milkbarandcoffe-web.github.io/lightroom/dzauto.json'
Core.GUIDA = 'https://milkbarandcoffe-web.github.io/lightroom/guida/'
Core.GRAZIA = 7 * 24 * 3600     -- senza internet la chiave vale ancora 7 giorni dall'ultimo controllo
Core.RICONTROLLO = 6 * 3600     -- controllo online al massimo ogni 6 ore
Core.FILIGRANA_COPYRIGHT = '<simpleCopyrightWatermark>'

local logger = LrLogger('DZAuto')
logger:enable('logfile')

function Core.prefs()
  return LrPrefs.prefsForPlugin()
end

function Core.trim(s)
  return (tostring(s or ''):gsub('^%s+', ''):gsub('%s+$', ''))
end

-- Diagnostica: file di log di Lightroom + ultime righe nelle preferenze (per COPIA DIAGNOSTICA).
function Core.log(msg)
  local riga = os.date('%d/%m %H:%M:%S') .. ' ' .. tostring(msg)
  logger:info(riga)
  local p = Core.prefs()
  local buf = p.diagnostica or ''
  buf = buf .. riga .. '\n'
  if #buf > 12000 then buf = buf:sub(-12000) end
  p.diagnostica = buf
end

function Core.urlencode(s)
  return (tostring(s or ''):gsub('[^%w%-_%.~]', function(c) return string.format('%%%02X', c:byte()) end))
end

local function intestazione(headers, nome)
  if type(headers) ~= 'table' then return nil end
  nome = nome:lower()
  for _, h in ipairs(headers) do
    if type(h) == 'table' and h.field and tostring(h.field):lower() == nome then return h.value end
  end
  return nil
end
Core._intestazione = intestazione

-- POST JSON al servizio chiavi. Gestisce il rimando (302) di Google Apps Script.
-- Ritorna tabella risposta oppure nil, errore.
function Core.chiama(dati, url)
  url = url or Core.LICENZE
  local corpo = Json.encode(dati)
  local testo, h = LrHttp.post(url, corpo, { { field = 'Content-Type', value = 'application/json' } }, 'POST', 30)
  local stato = type(h) == 'table' and h.status or nil
  if testo == nil then
    local e = type(h) == 'table' and h.error and (h.error.name or h.error.errorCode) or 'nessuna risposta'
    return nil, 'Rete: ' .. tostring(e)
  end
  local r = Json.decode(testo)
  if type(r) == 'table' then return r end
  if stato == 301 or stato == 302 or stato == 303 or stato == 307 or stato == 308 then
    local dove = intestazione(h, 'Location')
    if dove then
      local t2, h2 = LrHttp.get(dove, nil, 30)
      local r2 = Json.decode(t2 or '')
      if type(r2) == 'table' then return r2 end
      return nil, 'Risposta non valida dopo il rimando (' .. tostring(type(h2) == 'table' and h2.status) .. ')'
    end
  end
  return nil, 'Risposta non valida (HTTP ' .. tostring(stato) .. ')'
end

-- Configurazione pubblica (link del modulo domande e degli avvisi, versione nuova): cache 12 ore.
function Core.config(forza)
  local p = Core.prefs()
  local adesso = os.time()
  if not forza and p.configTesto and p.configQuando and adesso - p.configQuando < 12 * 3600 then
    local c = Json.decode(p.configTesto)
    if type(c) == 'table' then return c end
  end
  local testo = LrHttp.get(Core.CONFIG .. '?t=' .. adesso, nil, 20)
  local c = Json.decode(testo or '')
  if type(c) == 'table' then
    p.configTesto = testo
    p.configQuando = adesso
    return c
  end
  local vecchia = Json.decode(p.configTesto or '')
  return type(vecchia) == 'table' and vecchia or {}
end

-- Chiave: true oppure false, motivo. forza = controllo online subito.
function Core.licenza(forza)
  local p = Core.prefs()
  local k = Core.trim(p.chiave):upper()
  if k == '' then
    return false, 'Manca la chiave: File > Gestione plug-in > DZ Auto, scrivi la chiave e premi VERIFICA.'
  end
  local adesso = os.time()
  local scaduta = function() return p.licScade and p.licScade > 0 and adesso * 1000 > p.licScade end
  if not forza and p.licOk and p.licChiave == k and p.licUltimo and adesso - p.licUltimo < Core.RICONTROLLO and not scaduta() then
    return true
  end
  local r, err = Core.chiama({ azione = 'licenza', chiave = k, sid = '' })
  if r then
    if r.ok then
      p.licOk = true
      p.licChiave = k
      p.licUltimo = adesso
      p.licScade = tonumber(r.scade) or 0
      p.licPerpetua = r.perpetua and true or false
      p.licMotivo = nil
      Core.log('Chiave valida' .. (p.licScade > 0 and (' fino a ' .. os.date('%d/%m/%Y', math.floor(p.licScade / 1000))) or ''))
      return true
    end
    p.licOk = false
    p.licMotivo = r.motivo or 'Chiave non valida.'
    Core.log('Chiave rifiutata: ' .. p.licMotivo)
    return false, p.licMotivo
  end
  Core.log('Controllo chiave non riuscito: ' .. tostring(err))
  if p.licOk and p.licChiave == k and p.licUltimo and adesso - p.licUltimo < Core.GRAZIA and not scaduta() then
    return true
  end
  return false, 'Non riesco a controllare la chiave: serve internet (' .. tostring(err) .. ').'
end

function Core.statoLicenza()
  local p = Core.prefs()
  if not p.licOk then return p.licMotivo or 'Chiave non verificata.' end
  if p.licPerpetua then return 'Chiave valida (senza scadenza).' end
  if p.licScade and p.licScade > 0 then
    return 'Chiave valida fino al ' .. os.date('%d/%m/%Y', math.floor(p.licScade / 1000)) .. '.'
  end
  return 'Chiave valida.'
end

-- Invio al modulo "avvisi" (titolo, testo, chiave): la mail parte dall'app di Daniel verso Luca.
-- Lo usano l'avviso a fine lavoro e il conteggio del tempo risparmiato.
function Core.inviaModulo(titolo, testo)
  local c = Core.config(false)
  local a = type(c) == 'table' and c.avviso or nil
  if type(a) ~= 'table' or not a.url or not a.titolo or not a.testo then
    return false, 'Avvisi non ancora pronti: riprova più tardi.'
  end
  local p = Core.prefs()
  local corpo = a.titolo .. '=' .. Core.urlencode(titolo) .. '&' .. a.testo .. '=' .. Core.urlencode(testo)
  if a.chiave then corpo = corpo .. '&' .. a.chiave .. '=' .. Core.urlencode(Core.trim(p.chiave):upper()) end
  local r, h = LrHttp.post(a.url, corpo, { { field = 'Content-Type', value = 'application/x-www-form-urlencoded' } }, 'POST', 30)
  local stato = type(h) == 'table' and h.status or nil
  if r ~= nil and (stato == 200 or stato == 302 or stato == 303) then
    return true
  end
  return false, 'Avviso non inviato (HTTP ' .. tostring(stato) .. ').'
end

-- Avviso a fine lavoro.
function Core.avviso(titolo, testo)
  local ok, e = Core.inviaModulo(titolo, testo)
  if ok then
    Core.log('Avviso inviato: ' .. titolo)
    return true
  end
  Core.log(tostring(e))
  return false, e
end

-- Tempo risparmiato (stima). Secondi risparmiati per comando: valori di dzauto.json ("risparmio") o questi.
Core.RISPARMIO = { presetFoto = 2, esporta = 900, esportaFoto = 1, orologi = 600, firma = 60 }
Core.CONTA_TITOLO = 'DZ-CONTA'

function Core.coefficienti()
  local r = {}
  for k, v in pairs(Core.RISPARMIO) do r[k] = v end
  local c = Core.config(false)
  if type(c) == 'table' and type(c.risparmio) == 'table' then
    for k, v in pairs(c.risparmio) do
      local n = tonumber(v)
      if r[k] ~= nil and n and n >= 0 and n <= 36000 then r[k] = n end
    end
  end
  return r
end

function Core.stima(tipo, foto, coeff)
  local c = coeff or Core.coefficienti()
  local n = math.max(0, math.floor(tonumber(foto) or 0))
  if tipo == 'preset' then return n * c.presetFoto end
  if tipo == 'esporta' then return c.esporta + n * c.esportaFoto end
  if tipo == 'orologi' then return c.orologi end
  if tipo == 'firma' then return c.firma end
  return 0
end

local function leggiCoda(p)
  local coda = Json.decode(p.contaCoda or '')
  if type(coda) ~= 'table' then coda = {} end
  return coda
end

-- Conteggio anonimo: solo tipo di comando, numero di foto e durata. Niente nomi di servizi, file o foto.
-- Resta nella coda finche non viene inviato (anche giorni dopo, se manca internet).
function Core.segna(tipo, foto, durata)
  local p = Core.prefs()
  local s = Core.stima(tipo, foto)
  p.risparmioSec = (tonumber(p.risparmioSec) or 0) + s
  if not p.contaInst then
    local okR, x = pcall(math.random, 0, 65535)
    p.contaInst = string.format('%x%04x', os.time(), okR and x or 0)
  end
  p.contaSeq = (tonumber(p.contaSeq) or 0) + 1
  local coda = leggiCoda(p)
  coda[#coda + 1] = {
    id = p.contaInst .. '-' .. p.contaSeq,
    t = tipo,
    n = math.max(0, math.floor(tonumber(foto) or 0)),
    d = math.max(0, math.floor(tonumber(durata) or 0)),
    q = os.time()
  }
  while #coda > 300 do table.remove(coda, 1) end
  p.contaCoda = Json.encode(coda)
  return s
end

function Core.inviaConteggi()
  local p = Core.prefs()
  local coda = leggiCoda(p)
  if #coda == 0 then return true end
  local lotto = {}
  for i = 1, math.min(#coda, 40) do lotto[i] = coda[i] end
  local ok, e = Core.inviaModulo(Core.CONTA_TITOLO, Json.encode({ v = 1, voci = lotto }))
  if not ok then
    Core.log('Conteggio non inviato: ' .. tostring(e))
    return false
  end
  local resto = {}
  for i = #lotto + 1, #coda do resto[#resto + 1] = coda[i] end
  p.contaCoda = Json.encode(resto)
  return true
end

function Core.conta(tipo, foto, durata)
  local s = Core.segna(tipo, foto, durata)
  Core.inviaConteggi()
  return s
end

function Core.testoDurata(sec)
  sec = tonumber(sec) or 0
  if sec < 3600 then return string.format('%d min', math.floor(sec / 60 + 0.5)) end
  return (string.format('%.1f ore', sec / 3600):gsub('%.', ','))
end

function Core.testoRisparmio()
  local s = tonumber(Core.prefs().risparmioSec) or 0
  if s <= 0 then return 'Tempo risparmiato con DZ Auto (stima): appena usi i comandi lo vedi qui.' end
  return 'Tempo risparmiato con DZ Auto (stima): circa ' .. Core.testoDurata(s) .. '.'
end

-- Fotocamera di ogni foto e ora di scatto corretta con lo scarto degli orologi.
function Core.datiScatto(catalog, foto)
  local raw = catalog:batchGetRawMetadata(foto, { 'dateTimeOriginal', 'dateTime', 'pickStatus' })
  local fmt = catalog:batchGetFormattedMetadata(foto, { 'cameraModel', 'fileName' })
  local scarti = Core.prefs().scarti or {}
  local out = {}
  for i, ph in ipairs(foto) do
    local r = raw[ph] or {}
    local f = fmt[ph] or {}
    local modello = Core.trim(f.cameraModel)
    if modello == '' then modello = 'Fotocamera sconosciuta' end
    local t = tonumber(r.dateTimeOriginal) or tonumber(r.dateTime) or 0
    out[#out + 1] = {
      foto = ph,
      modello = modello,
      ora = t + (tonumber(scarti[modello]) or 0),
      nome = tostring(f.fileName or ''),
      scelta = tonumber(r.pickStatus) == 1,
      pos = i
    }
  end
  return out
end

-- Ordine di scatto: ora corretta, poi nome del file, poi posizione.
function Core.ordina(dati)
  table.sort(dati, function(a, b)
    if a.ora ~= b.ora then return a.ora < b.ora end
    if a.nome ~= b.nome then return a.nome < b.nome end
    return a.pos < b.pos
  end)
  return dati
end

function Core.modelli(dati)
  local visti, lista = {}, {}
  for _, d in ipairs(dati) do
    if not visti[d.modello] then
      visti[d.modello] = 0
      lista[#lista + 1] = d.modello
    end
    visti[d.modello] = visti[d.modello] + 1
  end
  table.sort(lista)
  return lista, visti
end

-- Scarto tra due foto dello stesso momento: la prima fotocamera e il riferimento.
-- Ritorna modelloRif, modelloAltro, secondi da aggiungere all'altra.
function Core.calcolaScarto(a, b)
  if a.modello == b.modello then return nil, nil, nil, 'Scegli due foto fatte con fotocamere diverse.' end
  local scarti = Core.prefs().scarti or {}
  local ta = a.ora - (tonumber(scarti[a.modello]) or 0)
  local tb = b.ora - (tonumber(scarti[b.modello]) or 0)
  return a.modello, b.modello, math.floor((ta - tb) * 100 + 0.5) / 100
end

function Core.salvaScarto(rif, altro, secondi)
  local p = Core.prefs()
  local s = {}
  for k, v in pairs(p.scarti or {}) do s[k] = v end
  s[rif] = 0
  s[altro] = secondi
  p.scarti = s
  p.scartiQuando = os.date('%d/%m/%Y %H:%M')
end

function Core.testoScarti()
  local p = Core.prefs()
  local righe = {}
  for k, v in pairs(p.scarti or {}) do
    if tonumber(v) and tonumber(v) ~= 0 then
      righe[#righe + 1] = string.format('%s: %+.2f s', k, v)
    end
  end
  table.sort(righe)
  if #righe == 0 then return 'Nessuno scarto: gli orologi sono considerati allineati.' end
  return table.concat(righe, ', ') .. (p.scartiQuando and (' (impostato il ' .. p.scartiQuando .. ')') or '')
end

-- Lavoro a gruppi piccoli nel catalogo (meno blocchi di Lightroom), con avanzamento e Annulla.
function Core.aGruppi(catalog, nomeAzione, elementi, gruppo, fn, avanzamento)
  local fatti, errori = 0, {}
  local n = #elementi
  for inizio = 1, n, gruppo do
    if avanzamento and avanzamento:isCanceled() then break end
    local fine = math.min(n, inizio + gruppo - 1)
    catalog:withWriteAccessDo(nomeAzione, function()
      for i = inizio, fine do
        local ok, e = Core.pcall(fn, elementi[i])
        if ok then fatti = fatti + 1 else errori[#errori + 1] = tostring(e) end
      end
    end, { timeout = 60 })
    if avanzamento then
      avanzamento:setPortionComplete(fine, n)
      avanzamento:setCaption(string.format('%d di %d', fine, n))
    end
    LrTasks.yield()
    -- 1.1.1: se tutto il primo gruppo va in errore mi fermo (stesso errore su tutte le foto).
    if inizio == 1 and fatti == 0 and #errori >= fine then
      Core.log('Fermo dopo il primo gruppo: ' .. tostring(errori[1]))
      break
    end
  end
  return fatti, errori
end

-- Primo errore in breve, da mostrare nella finestra (il resto e nella diagnostica).
function Core.primoErrore(errori)
  if not errori or #errori == 0 then return '' end
  local e = tostring(errori[1]):gsub('%s+', ' ')
  if #e > 220 then e = e:sub(1, 220) .. '...' end
  return '\nPrimo errore: ' .. e
end

-- Preset di sviluppo: elenco { titolo = 'Cartella / Nome', uuid = ... }
function Core.preset()
  local lista = {}
  for _, cartella in ipairs(LrApplication.developPresetFolders() or {}) do
    for _, pr in ipairs(cartella:getDevelopPresets() or {}) do
      lista[#lista + 1] = { titolo = cartella:getName() .. ' / ' .. pr:getName(), uuid = pr:getUuid() }
    end
  end
  table.sort(lista, function(a, b) return a.titolo:lower() < b.titolo:lower() end)
  return lista
end

-- Firma e copyright nei metadati della foto (le voci non accettate vengono saltate e annotate).
Core.CAMPI_FIRMA = {
  { campo = 'creator', pref = 'firmaAutore' },
  { campo = 'copyright', pref = 'firmaCopyright' },
  { campo = 'creatorEmail', pref = 'firmaEmail' },
  { campo = 'creatorUrl', pref = 'firmaSito' },
  { campo = 'creatorPhone', pref = 'firmaTelefono' }
}

function Core.firmaPronta()
  local p = Core.prefs()
  return Core.trim(p.firmaAutore) ~= '' or Core.trim(p.firmaCopyright) ~= ''
end

function Core.scriviFirma(foto)
  local p = Core.prefs()
  for _, c in ipairs(Core.CAMPI_FIRMA) do
    local v = Core.trim(p[c.pref])
    if v ~= '' then
      local ok, e = Core.pcall(function() foto:setRawMetadata(c.campo, v) end)
      if not ok then Core.log('Firma: campo ' .. c.campo .. ' non accettato: ' .. tostring(e)) end
    end
  end
  if Core.trim(p.firmaCopyright) ~= '' then
    Core.pcall(function() foto:setRawMetadata('copyrightState', 'copyrighted') end)
  end
end

-- Filigrane create in Lightroom (file .lrtemplate): { titolo, id }
function Core.leggiFiligrana(testo)
  if type(testo) ~= 'string' then return nil end
  local id = testo:match('id%s*=%s*"([^"]+)"')
  local titolo = testo:match('title%s*=%s*"([^"]*)"') or testo:match('internalName%s*=%s*"([^"]*)"')
  if id and titolo then return { titolo = titolo, id = id } end
  return nil
end

function Core.cartelleFiligrane()
  local c = {}
  local function prova(base, ...)
    if not base then return end
    local p = base
    for _, x in ipairs({ ... }) do p = LrPathUtils.child(p, x) end
    c[#c + 1] = p
  end
  local okA, appData = pcall(LrPathUtils.getStandardFilePath, 'appData')
  local okH, home = pcall(LrPathUtils.getStandardFilePath, 'home')
  if okA then
    prova(appData, 'Watermarks')
    prova(appData, 'Adobe', 'Lightroom', 'Watermarks')
  end
  if okH then
    prova(home, 'Library', 'Application Support', 'Adobe', 'Lightroom', 'Watermarks')
  end
  return c
end

function Core.filigrane()
  local lista, visti = {}, {}
  for _, dir in ipairs(Core.cartelleFiligrane()) do
    if LrFileUtils.exists(dir) == 'directory' then
      for file in LrFileUtils.files(dir) do
        if tostring(file):lower():match('%.lrtemplate$') then
          local w = Core.leggiFiligrana(LrFileUtils.readFile(file))
          if w and not visti[w.id] then
            visti[w.id] = true
            lista[#lista + 1] = w
          end
        end
      end
    end
  end
  table.sort(lista, function(a, b) return a.titolo:lower() < b.titolo:lower() end)
  return lista
end

-- Nome sicuro per file e cartelle
function Core.nomeFile(s)
  s = Core.trim(s):gsub('[/\\:%*%?"<>|]', '-'):gsub('%s+', ' ')
  if s == '' then s = 'Servizio' end
  return s
end

-- Rinomina con numero a 4 cifre; se il nome esiste aggiunge -2, -3...
function Core.rinomina(percorso, base, numero)
  local cartella = LrPathUtils.parent(percorso)
  local est = LrPathUtils.extension(percorso)
  local nome = string.format('%s_%04d', base, numero)
  local dest = LrPathUtils.child(cartella, nome .. '.' .. est)
  local k = 2
  while LrFileUtils.exists(dest) and dest ~= percorso do
    dest = LrPathUtils.child(cartella, string.format('%s-%d.%s', nome, k, est))
    k = k + 1
  end
  if dest == percorso then return true, dest end
  local ok, e = LrFileUtils.move(percorso, dest)
  if ok == false then return false, e end
  return true, dest
end

return Core
