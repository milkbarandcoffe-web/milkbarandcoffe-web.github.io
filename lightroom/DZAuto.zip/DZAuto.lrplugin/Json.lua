-- DZ Auto - idea e sviluppo by Daniel
-- JSON minimo (Lua 5.1): encode e decode per le risposte del servizio chiavi e la configurazione.

local Json = {}

local function escStr(s)
  s = s:gsub('[%c"\\]', function(c)
    if c == '"' then return '\\"' end
    if c == '\\' then return '\\\\' end
    if c == '\n' then return '\\n' end
    if c == '\r' then return '\\r' end
    if c == '\t' then return '\\t' end
    return string.format('\\u%04x', c:byte())
  end)
  return '"' .. s .. '"'
end

local function isArray(t)
  local n = 0
  for k in pairs(t) do
    if type(k) ~= 'number' or k < 1 or math.floor(k) ~= k then return false end
    n = n + 1
  end
  for i = 1, n do if t[i] == nil then return false end end
  return true, n
end

function Json.encode(v)
  local t = type(v)
  if v == nil then return 'null' end
  if t == 'boolean' then return v and 'true' or 'false' end
  if t == 'number' then
    if v ~= v or v == math.huge or v == -math.huge then return 'null' end
    if math.floor(v) == v and math.abs(v) < 1e15 then return string.format('%d', v) end
    return string.format('%.14g', v)
  end
  if t == 'string' then return escStr(v) end
  if t == 'table' then
    local arr, n = isArray(v)
    local out = {}
    if arr and n > 0 then
      for i = 1, n do out[#out + 1] = Json.encode(v[i]) end
      return '[' .. table.concat(out, ',') .. ']'
    end
    local keys = {}
    for k in pairs(v) do keys[#keys + 1] = tostring(k) end
    table.sort(keys)
    for _, k in ipairs(keys) do
      local val = v[k]
      if val == nil then val = v[tonumber(k)] end
      out[#out + 1] = escStr(k) .. ':' .. Json.encode(val)
    end
    return '{' .. table.concat(out, ',') .. '}'
  end
  return 'null'
end

-- utf8 di un codice unicode
local function utf8(cp)
  if cp < 0x80 then return string.char(cp) end
  if cp < 0x800 then return string.char(0xC0 + math.floor(cp / 0x40), 0x80 + cp % 0x40) end
  if cp < 0x10000 then
    return string.char(0xE0 + math.floor(cp / 0x1000), 0x80 + math.floor(cp / 0x40) % 0x40, 0x80 + cp % 0x40)
  end
  return string.char(0xF0 + math.floor(cp / 0x40000), 0x80 + math.floor(cp / 0x1000) % 0x40,
    0x80 + math.floor(cp / 0x40) % 0x40, 0x80 + cp % 0x40)
end

-- Ritorna valore oppure nil, messaggio di errore.
function Json.decode(s)
  if type(s) ~= 'string' then return nil, 'testo mancante' end
  local i = 1
  local function err(m) error({ json = true, msg = m .. ' (posizione ' .. i .. ')' }) end
  local function ws() i = s:find('[^ \t\r\n]', i) or (#s + 1) end
  local value
  local function str()
    i = i + 1
    local out = {}
    while true do
      local c = s:sub(i, i)
      if c == '' then err('stringa non chiusa') end
      if c == '"' then i = i + 1; break end
      if c == '\\' then
        local e = s:sub(i + 1, i + 1)
        local map = { ['"'] = '"', ['\\'] = '\\', ['/'] = '/', b = '\b', f = '\f', n = '\n', r = '\r', t = '\t' }
        if map[e] then out[#out + 1] = map[e]; i = i + 2
        elseif e == 'u' then
          local h = s:sub(i + 2, i + 5)
          if not h:match('^%x%x%x%x$') then err('\\u non valido') end
          local cp = tonumber(h, 16)
          i = i + 6
          if cp >= 0xD800 and cp <= 0xDBFF and s:sub(i, i + 1) == '\\u' then
            local lo = tonumber(s:sub(i + 2, i + 5), 16)
            if lo and lo >= 0xDC00 and lo <= 0xDFFF then
              cp = 0x10000 + (cp - 0xD800) * 0x400 + (lo - 0xDC00)
              i = i + 6
            end
          end
          out[#out + 1] = utf8(cp)
        else err('escape non valido') end
      else
        local j = s:find('["\\]', i)
        if not j then err('stringa non chiusa') end
        out[#out + 1] = s:sub(i, j - 1)
        i = j
      end
    end
    return table.concat(out)
  end
  function value()
    ws()
    local c = s:sub(i, i)
    if c == '{' then
      i = i + 1
      local o = {}
      ws()
      if s:sub(i, i) == '}' then i = i + 1; return o end
      while true do
        ws()
        if s:sub(i, i) ~= '"' then err('chiave attesa') end
        local k = str()
        ws()
        if s:sub(i, i) ~= ':' then err('":" atteso') end
        i = i + 1
        o[k] = value()
        ws()
        local d = s:sub(i, i)
        i = i + 1
        if d == '}' then return o end
        if d ~= ',' then err('"," o "}" atteso') end
      end
    elseif c == '[' then
      i = i + 1
      local a = {}
      ws()
      if s:sub(i, i) == ']' then i = i + 1; return a end
      while true do
        a[#a + 1] = value()
        ws()
        local d = s:sub(i, i)
        i = i + 1
        if d == ']' then return a end
        if d ~= ',' then err('"," o "]" atteso') end
      end
    elseif c == '"' then
      return str()
    elseif s:sub(i, i + 3) == 'true' then i = i + 4; return true
    elseif s:sub(i, i + 4) == 'false' then i = i + 5; return false
    elseif s:sub(i, i + 3) == 'null' then i = i + 4; return nil
    else
      local n = s:match('^-?%d+%.?%d*[eE]?[-+]?%d*', i)
      if not n or n == '' or n == '-' then err('valore non valido') end
      i = i + #n
      return tonumber(n)
    end
  end
  local ok, res = pcall(function()
    local v = value()
    ws()
    if i <= #s then err('testo in piu') end
    return v
  end)
  if ok then return res end
  if type(res) == 'table' and res.json then return nil, res.msg end
  return nil, tostring(res)
end

return Json
