-- DZ Auto - idea e sviluppo by Daniel
-- Domande, richieste e suggerimenti: apre il modulo nel browser.

local LrHttp = import 'LrHttp'
local LrTasks = import 'LrTasks'

local Core = require 'Core'

LrTasks.startAsyncTask(function()
  local c = Core.config(false)
  local url = type(c) == 'table' and c.domande or nil
  if not url or url == '' then url = Core.GUIDA end
  LrHttp.openUrlInBrowser(url)
end)
