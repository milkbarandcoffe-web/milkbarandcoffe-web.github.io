-- DZ Auto 2.0 - idea e sviluppo by Daniel Zavan
-- Aggiornamento da solo: legge la versione nuova da dzauto.json, scarica lo zip, lo apre in una cartella
-- temporanea, controlla che sia DZ Auto e copia i file sopra quelli del plugin. Poi serve riaprire Lightroom.

local LrHttp = import 'LrHttp'
local LrTasks = import 'LrTasks'
local LrFileUtils = import 'LrFileUtils'
local LrPathUtils = import 'LrPathUtils'

local Core = require 'Core'

local Aggiorna = {}
Aggiorna.ZIP = 'https://milkbarandcoffe-web.github.io/lightroom/DZAuto.zip'

local function q(s)
  return "'" .. tostring(s):gsub("'", "'\\''") .. "'"
end

-- Ritorna versione pubblicata, true se e piu nuova di questa.
function Aggiorna.controlla(forza)
  local c = Core.config(forza)
  local v = type(c) == 'table' and c.versione or nil
  return v, v ~= nil and Core.versioneMaggiore(v, Core.VERSIONE)
end

function Aggiorna.testo(v, nuova)
  if nuova then return 'C\'e la versione ' .. tostring(v) .. ' (tu hai la ' .. Core.VERSIONE .. '): premi AGGIORNA ORA.' end
  if v then return 'Versione ' .. Core.VERSIONE .. ': e l\'ultima.' end
  return 'Versione ' .. Core.VERSIONE .. '. Non riesco a controllare gli aggiornamenti (serve internet).'
end

-- true, versione installata  oppure  false, motivo
function Aggiorna.installa()
  if MAC_ENV == false then return false, 'L\'aggiornamento da solo funziona sul Mac.' end
  local c = Core.config(true)
  local url = (type(c) == 'table' and c.scarica) or Aggiorna.ZIP
  local corpo = LrHttp.get(url .. '?t=' .. os.time(), nil, 90)
  if type(corpo) ~= 'string' or #corpo < 1000 or corpo:sub(1, 2) ~= 'PK' then
    return false, 'Download non riuscito: controlla internet e riprova.'
  end
  local tmp = LrPathUtils.child(LrPathUtils.getStandardFilePath('temp'), 'dzauto-aggiorna-' .. os.time())
  LrFileUtils.createAllDirectories(tmp)
  local zip = LrPathUtils.child(tmp, 'DZAuto.zip')
  local fh = io.open(zip, 'wb')
  if not fh then return false, 'Non riesco a salvare lo zip.' end
  fh:write(corpo)
  fh:close()
  local fuori = LrPathUtils.child(tmp, 'nuovo')
  local rc = LrTasks.execute('/usr/bin/ditto -x -k ' .. q(zip) .. ' ' .. q(fuori))
  if rc ~= 0 then return false, 'Non riesco ad aprire lo zip (codice ' .. tostring(rc) .. ').' end
  local nuovo = LrPathUtils.child(fuori, 'DZAuto.lrplugin')
  if LrFileUtils.exists(LrPathUtils.child(nuovo, 'Info.lua')) ~= 'file' then
    return false, 'Lo zip scaricato non contiene DZ Auto.'
  end
  local v = (LrFileUtils.readFile(LrPathUtils.child(nuovo, 'Core.lua')) or ''):match("Core%.VERSIONE = '([%d%.]+)'")
  if not v then return false, 'Versione non trovata nello zip.' end
  local rc2 = LrTasks.execute('/usr/bin/ditto ' .. q(nuovo) .. ' ' .. q(_PLUGIN.path))
  if rc2 ~= 0 then return false, 'Copia non riuscita (codice ' .. tostring(rc2) .. ').' end
  Core.log('Aggiornato alla ' .. v .. ' in ' .. tostring(_PLUGIN.path))
  return true, v
end

return Aggiorna
