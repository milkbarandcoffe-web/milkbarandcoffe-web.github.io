-- DZ Auto 2.0.1 - idea e sviluppo by Daniel Zavan
-- File > Extra plug-in > DZ Auto: Aiuto e messaggi. Apre la pagina Aiuto (messaggi, file, versioni nuove).

local LrDialogs = import 'LrDialogs'
local LrTasks = import 'LrTasks'

local Aiuto = require 'Aiuto'

LrTasks.startAsyncTask(function()
  local ok, motivo = Aiuto.apri()
  if not ok then
    LrDialogs.message('DZ Auto', 'La pagina Aiuto non si apre: ' .. tostring(motivo) .. '\nHo aperto il modulo delle domande.', 'info')
  end
end)
