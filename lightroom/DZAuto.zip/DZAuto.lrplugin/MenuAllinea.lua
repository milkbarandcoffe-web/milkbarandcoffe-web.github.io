-- DZ Auto - idea e sviluppo by Daniel
-- Allinea orologi: due foto dello stesso istante, una per fotocamera. Il plugin calcola lo scarto
-- e lo usa per l'ordine di scatto della consegna. I file e i metadati NON vengono cambiati.

local LrApplication = import 'LrApplication'
local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrTasks = import 'LrTasks'

local Core = require 'Core'

local function allinea(context)
  LrDialogs.attachErrorDialogToFunctionContext(context)
  local ok, motivo = Core.licenza(false)
  if not ok then
    LrDialogs.message('DZ Auto', motivo, 'warning')
    return
  end

  local catalog = LrApplication.activeCatalog()
  local foto = catalog:getTargetPhotos()
  if #foto ~= 2 then
    LrDialogs.message('DZ Auto: allinea orologi',
      'Seleziona 2 foto dello stesso istante, una per fotocamera (per esempio il bacio o il lancio del riso), poi riprova.\n\n' ..
      'Adesso: ' .. Core.testoScarti(), 'info')
    return
  end

  local d = Core.datiScatto(catalog, foto)
  local rif, altro, secondi, errore = Core.calcolaScarto(d[1], d[2])
  if not rif then
    LrDialogs.message('DZ Auto', errore, 'warning')
    return
  end

  local testo
  if secondi == 0 then
    testo = string.format('%s e %s sono già allineate.', rif, altro)
  else
    testo = string.format('%s è %s di %.2f secondi rispetto a %s.', altro, secondi > 0 and 'indietro' or 'avanti', math.abs(secondi), rif)
  end
  local scelta = LrDialogs.confirm('DZ Auto: allinea orologi',
    testo .. '\n\nSalvo lo scarto? Vale per l\'ordine delle foto nella consegna. I file non vengono cambiati.',
    'Salva', 'Annulla')
  if scelta ~= 'ok' then return end
  Core.salvaScarto(rif, altro, secondi)
  Core.log('Scarto orologi: ' .. Core.testoScarti())
  LrDialogs.message('DZ Auto', 'Fatto. ' .. Core.testoScarti(), 'info')
end

LrTasks.startAsyncTask(function()
  LrFunctionContext.callWithContext('DZ Auto allinea orologi', allinea)
end)
