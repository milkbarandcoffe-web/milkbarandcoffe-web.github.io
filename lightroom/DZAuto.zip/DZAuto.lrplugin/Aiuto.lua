-- DZ Auto 2.0.1 - idea e sviluppo by Daniel Zavan
-- Aiuto e segnalazioni: apre la pagina Aiuto di Luca (il link lo da l'app di Daniel, con la chiave)
-- e manda una segnalazione (testo, riepilogo dell'ultimo lavoro, diagnostica, schermata del Mac).
-- Indirizzo dell'app: "aiuto" in dzauto.json. Le foto non escono mai: solo testo e, se Luca vuole, la schermata.

local LrApplication = import 'LrApplication'
local LrFileUtils = import 'LrFileUtils'
local LrHttp = import 'LrHttp'
local LrPathUtils = import 'LrPathUtils'
local LrTasks = import 'LrTasks'

local Core = require 'Core'

local Aiuto = {}

local B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

-- Base64 (Lua 5.1, senza librerie).
function Aiuto.base64(s)
  local out, n = {}, #s
  for i = 1, n, 3 do
    local a, b, c = s:byte(i, i + 2)
    local x = a * 65536 + (b or 0) * 256 + (c or 0)
    local d1 = math.floor(x / 262144) % 64
    local d2 = math.floor(x / 4096) % 64
    local d3 = math.floor(x / 64) % 64
    local d4 = x % 64
    out[#out + 1] = B64:sub(d1 + 1, d1 + 1) .. B64:sub(d2 + 1, d2 + 1) ..
      (b and B64:sub(d3 + 1, d3 + 1) or '=') .. (c and B64:sub(d4 + 1, d4 + 1) or '=')
  end
  return table.concat(out)
end

function Aiuto.indirizzo()
  local c = Core.config(false)
  local u = type(c) == 'table' and c.aiuto or nil
  if type(u) == 'string' and u:match('^https://') then return u end
  return nil
end

-- { ok, url, nuovi } oppure nil, motivo
function Aiuto.chiedi()
  local u = Aiuto.indirizzo()
  if not u then return nil, 'Pagina Aiuto non ancora pronta.' end
  local k = Core.trim(Core.prefs().chiave):upper()
  if k == '' then return nil, 'Manca la chiave: File > Gestione plug-in > DZ Auto.' end
  local r, e = Core.chiama({ azione = 'aiuto', chiave = k }, u)
  if not r then return nil, e end
  if not r.ok then return nil, r.motivo or 'Non riesco ad aprire la pagina Aiuto.' end
  return r
end

-- Apre la pagina Aiuto nel browser. Se non si puo: il modulo domande (o la guida) e il motivo.
function Aiuto.apri()
  local r, motivo = Aiuto.chiedi()
  if r and r.url then
    LrHttp.openUrlInBrowser(r.url)
    return true
  end
  Core.log('Aiuto non aperto: ' .. tostring(motivo))
  local c = Core.config(false)
  LrHttp.openUrlInBrowser((type(c) == 'table' and c.domande) or Core.GUIDA)
  return false, motivo
end

local function q(s)
  return "'" .. tostring(s):gsub("'", "'\\''") .. "'"
end

local function leggiTutto(p)
  local fh = io.open(p, 'rb')
  if not fh then return nil end
  local t = fh:read('*a')
  fh:close()
  return t
end

-- Schermata del Mac (schermo principale), ridotta a 2200 px. La prima volta il Mac chiede il permesso
-- "Registrazione schermo" per Lightroom. Ritorna il contenuto JPEG oppure nil, motivo.
function Aiuto.schermata()
  if MAC_ENV == false then return nil, 'La schermata funziona sul Mac.' end
  local p = LrPathUtils.child(LrPathUtils.getStandardFilePath('temp'), 'dzauto-schermata-' .. os.time() .. '.jpg')
  local rc = LrTasks.execute('/usr/sbin/screencapture -x -t jpg ' .. q(p))
  if rc ~= 0 or LrFileUtils.exists(p) ~= 'file' then
    return nil, 'Schermata non riuscita (codice ' .. tostring(rc) .. '): controlla Impostazioni di Sistema > Privacy e sicurezza > Registrazione schermo > Lightroom Classic.'
  end
  LrTasks.execute('/usr/bin/sips -Z 2200 -s formatOptions 75 ' .. q(p) .. ' >/dev/null 2>&1')
  local dati = leggiTutto(p)
  LrFileUtils.delete(p)
  if not dati or #dati < 100 then return nil, 'Schermata vuota.' end
  return dati
end

function Aiuto.versioni()
  local lr, os_ = '?', '?'
  local ok, v = Core.pcall(function() return LrApplication.versionString() end)
  if ok and v then lr = tostring(v) end
  local ok2, si = Core.pcall(function() return import('LrSystemInfo').osVersion() end)
  if ok2 and si then os_ = tostring(si) end
  return 'DZ Auto ' .. Core.VERSIONE .. ' · Lightroom ' .. lr .. ' · ' .. os_
end

-- o = { testo, riepilogo (bool), diagnostica (bool), schermata (bool), tipo }
-- Ritorna true oppure false, motivo. Avvisi (es. schermata non riuscita) nel secondo valore anche se ok.
function Aiuto.segnala(o)
  local u = Aiuto.indirizzo()
  if not u then return false, 'Pagina Aiuto non ancora pronta.' end
  local k = Core.trim(Core.prefs().chiave):upper()
  if k == '' then return false, 'Manca la chiave: File > Gestione plug-in > DZ Auto.' end
  local p = Core.prefs()
  local parti = {}
  if Core.trim(o.testo) ~= '' then parti[#parti + 1] = Core.trim(o.testo) end
  if o.riepilogo and p.ultimoRiepilogo then parti[#parti + 1] = 'Ultimo lavoro:\n' .. tostring(p.ultimoRiepilogo) end
  parti[#parti + 1] = Aiuto.versioni()
  local file, nota = {}, nil
  if o.diagnostica then
    local t = 'DZ Auto ' .. Core.VERSIONE .. '\n' .. Core.statoLicenza() .. '\n' .. Core.testoScarti() .. '\n\n' .. (p.diagnostica or '(vuota)')
    file[#file + 1] = { nome = 'diagnostica.txt', mime = 'text/plain', b64 = Aiuto.base64(t) }
  end
  if o.schermata then
    local img, perche = Aiuto.schermata()
    if img then
      file[#file + 1] = { nome = 'schermata_mac.jpg', mime = 'image/jpeg', b64 = Aiuto.base64(img) }
    else
      nota = perche
      parti[#parti + 1] = '(Schermata non allegata: ' .. tostring(perche) .. ')'
    end
  end
  local r, e = Core.chiama({ azione = 'segnala', chiave = k, tipo = o.tipo or 'Segnalazione', testo = table.concat(parti, '\n\n'), file = file }, u)
  if not r then return false, e end
  if not r.ok then return false, r.motivo or 'Non inviata.' end
  Core.log('Segnalazione inviata (' .. #file .. ' allegati)')
  return true, nota
end

return Aiuto
