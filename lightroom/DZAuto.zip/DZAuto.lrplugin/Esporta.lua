-- DZ Auto - idea e sviluppo by Daniel
-- Esporta consegna: foto in ordine di scatto (orologi allineati), nome scelto + numero a 4 cifre,
-- versione alta qualita e versione web, filigrana a scelta, firma, avviso a fine lavoro.

local LrExportSession = import 'LrExportSession'
local LrFileUtils = import 'LrFileUtils'
local LrPathUtils = import 'LrPathUtils'
local LrProgressScope = import 'LrProgressScope'

local Core = require 'Core'

local Esporta = {}

Esporta.WEB_LATO = 2048
Esporta.WEB_QUALITA = 0.8

-- Impostazioni di esportazione di Lightroom (chiavi LR_*).
function Esporta.impostazioni(o)
  local s = {
    LR_export_destinationType = 'specificFolder',
    LR_export_destinationPathPrefix = o.cartella,
    LR_export_useSubfolder = true,
    LR_export_destinationPathSuffix = o.sottocartella,
    LR_collisionHandling = 'rename',
    LR_format = 'JPEG',
    LR_jpeg_quality = o.web and Esporta.WEB_QUALITA or 1,
    LR_export_colorSpace = 'sRGB',
    LR_export_bitDepth = 8,
    LR_size_doConstrain = o.web and true or false,
    LR_size_doNotEnlarge = true,
    LR_reimportExportedPhoto = false,
    LR_renamingTokensOn = false,
    LR_useWatermark = o.filigrana and true or false,
    LR_minimizeEmbeddedMetadata = false
  }
  if o.web then
    s.LR_size_resizeType = 'longEdge'
    s.LR_size_maxWidth = Esporta.WEB_LATO
    s.LR_size_maxHeight = Esporta.WEB_LATO
    s.LR_size_units = 'pixels'
    s.LR_size_resolution = 72
    s.LR_outputSharpeningOn = true
    s.LR_outputSharpeningMedia = 'screen'
    s.LR_outputSharpeningLevel = 2
  else
    s.LR_outputSharpeningOn = false
  end
  if o.filigrana then s.LR_watermarking_id = o.filigranaId or Core.FILIGRANA_COPYRIGHT end
  return s
end

-- Versioni da fare con le scelte della finestra.
function Esporta.versioni(o)
  local v = {}
  if o.alta then
    v[#v + 1] = { nome = 'Alta', web = false, filigrana = o.filigrana == 'tutte' }
  end
  if o.web then
    v[#v + 1] = { nome = 'Web', web = true, filigrana = o.filigrana == 'tutte' or o.filigrana == 'web' }
  end
  return v
end

-- o = { catalog, dati (gia ordinati), base, cartella, alta, web, filigrana ('nessuna'|'web'|'tutte'),
--       filigranaId, firma, context }
-- Ritorna { totale, versioni = { {nome, ok, errori, cartella} }, errori = {...} }
function Esporta.esegui(o)
  local base = Core.nomeFile(o.base)
  local foto, numero = {}, {}
  for i, d in ipairs(o.dati) do
    foto[#foto + 1] = d.foto
    numero[d.foto] = i
  end
  local esito = { totale = #foto, versioni = {}, errori = {} }

  if o.firma and Core.firmaPronta() then
    local av = LrProgressScope { title = 'DZ Auto: firma e copyright', functionContext = o.context }
    local _, err = Core.aGruppi(o.catalog, 'DZ Auto: firma', foto, 50, Core.scriviFirma, av)
    av:done()
    for _, e in ipairs(err) do esito.errori[#esito.errori + 1] = 'firma: ' .. e end
  end

  for _, v in ipairs(Esporta.versioni(o)) do
    -- cartella nuova a ogni esportazione: mai sovrascrivere una consegna precedente
    local sotto = base .. ' - ' .. v.nome
    local k = 2
    while LrFileUtils.exists(LrPathUtils.child(o.cartella, sotto)) do
      sotto = string.format('%s - %s (%d)', base, v.nome, k)
      k = k + 1
    end
    local s = Esporta.impostazioni {
      cartella = o.cartella, sottocartella = sotto, web = v.web,
      filigrana = v.filigrana, filigranaId = o.filigranaId
    }
    local r = { nome = v.nome, ok = 0, errori = 0, cartella = LrPathUtils.child(o.cartella, sotto) }
    local av = LrProgressScope { title = 'DZ Auto: esporto ' .. v.nome .. ' (' .. #foto .. ' foto)', functionContext = o.context }
    Core.log(string.format('Esporta %s: %d foto in %s', v.nome, #foto, r.cartella))
    local sessione = LrExportSession { photosToExport = foto, exportSettings = s }
    for _, rendition in sessione:renditions { progressScope = av, renderProgressPortion = 1, stopIfCanceled = true } do
      local fatto, percorso = rendition:waitForRender()
      if fatto then
        local n = numero[rendition.photo] or (r.ok + r.errori + 1)
        local okR, nuovo = Core.rinomina(percorso, base, n)
        if okR then
          r.ok = r.ok + 1
        else
          r.errori = r.errori + 1
          esito.errori[#esito.errori + 1] = 'rinomina: ' .. tostring(nuovo)
        end
      else
        r.errori = r.errori + 1
        esito.errori[#esito.errori + 1] = v.nome .. ': ' .. tostring(percorso)
      end
    end
    r.interrotto = av:isCanceled()
    av:done()
    esito.versioni[#esito.versioni + 1] = r
    if r.interrotto then break end
  end
  for _, e in ipairs(esito.errori) do Core.log('Errore esportazione: ' .. e) end
  return esito
end

function Esporta.riepilogo(base, esito)
  local parti = {}
  for _, v in ipairs(esito.versioni) do
    parti[#parti + 1] = string.format('%s %d', v.nome:lower(), v.ok) .. (v.errori > 0 and string.format(' (%d errori)', v.errori) or '')
  end
  local t = string.format('%s: %d foto, %s.', Core.nomeFile(base), esito.totale, table.concat(parti, ', '))
  for _, v in ipairs(esito.versioni) do
    if v.interrotto then t = t .. ' Interrotto.' break end
  end
  return t
end

return Esporta
